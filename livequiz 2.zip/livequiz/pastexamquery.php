<?php
session_start();
include "loginstuff/access.php";
access();
$userid = $_SESSION["userid"];

$requestPayload = file_get_contents("php://input");
$object = json_decode($requestPayload);
$strexam = strval($object);
$dbhost = "localhost";
$dbuser = "root";
$dbpass = "";
$dbname = "demoquestions";
$connection = mysqli_connect($dbhost, $dbuser, $dbpass, $dbname);

//send last answer and qids in order for exam to alluserattempts and then recreate exam with modified sliderattempt4
$question_query = "SELECT question_id FROM alluserattempts WHERE exam_number = $strexam AND user_id = '$userid'";
$que_query_run = mysqli_query($connection,$question_query);
$questionids = array();
while ($row3 = mysqli_fetch_assoc($que_query_run)){
        $qidsforarray = $row3['question_id'];
        array_push($questionids, $qidsforarray);
    }
//echo json_encode($questionids);
$qidarray = implode(",",$questionids);

$no_of_ques = (count($questionids));


$data = array();
$explanation = array();
$options = array();
$lastanswers = array();
$secondstaken = array();
for ($x=0; $x<$no_of_ques; $x++){
    $qid_for_query = $questionids[$x];
    $question_query = "SELECT * FROM questions WHERE question_number = ".$qid_for_query."";
    $que_query_run = mysqli_query($connection,$question_query);
    $row = mysqli_fetch_assoc($que_query_run);
    array_push($data, $row);
    $explanation_query = "SELECT * FROM explanations WHERE explanation_number = ".$qid_for_query.""; 
    $exp_query_run = mysqli_query($connection, $explanation_query);
    $row4 = mysqli_fetch_assoc($exp_query_run);
    array_push($explanation, $row4);
    $option_query = "SELECT * FROM options WHERE question_number = ".$qid_for_query.""; 
    $opt_query_run = mysqli_query($connection, $option_query);
    while ($row5 = mysqli_fetch_assoc($opt_query_run)){
        array_push($options, $row5);
    }
    $user_subs_query = "SELECT last_answer,seconds_taken FROM alluserattempts WHERE exam_number = $strexam AND question_id =".$qid_for_query."";
    $subs_query = mysqli_query($connection,$user_subs_query);
    $sub_query_run = mysqli_fetch_assoc($subs_query);
    $row6 = $sub_query_run['last_answer'];
    $row7 = $sub_query_run['seconds_taken'];
    array_push($lastanswers,$row6);
    array_push($secondstaken,$row7);
}
$suparr = array();
array_push($suparr,$data);
array_push($suparr,$explanation);
array_push($suparr,$options);
array_push($suparr,$lastanswers);
array_push($suparr,$secondstaken);

echo json_encode($suparr);

?>
