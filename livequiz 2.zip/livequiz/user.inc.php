<?php
class user extends Dbh {
    public function getAll(){
        $userid = $_SESSION["userid"];
        $all = 'all';
        $counter = 0;
        $color1 = "#002855";
        $color2 = "#EAAA00";
        $color = $color1;
//        Shadeed webkit-appearance:none https://stackoverflow.com/questions/34543313/how-to-make-a-input-submit-button-with-flat-look
        $stmt = $this->connect()->query("SELECT `exam`, COUNT(*) AS `count` FROM questions GROUP BY `exam`");
        while ($row = $stmt->fetch()){
            $color == $color1 ? $color = $color2 : $color = $color1;
            $exam = $row['exam'];
            $count = $row['count'];   
            $echostring1 = "<tr><td style='width:150px'></td><td style='vertical-align:top;'>"
                    . "<input type='checkbox' style='width:17px;height:17px;' onclick='examstr($counter);loadtable($all);' id='exam$counter'></td>"
                    . "<td><div class='multiselect'>"
                . "<div class='selectBox' onclick='showCheckboxes($counter)'>"
                        . "<select id='bean$counter'style='color:white;background-color:$color;"
                    . "-webkit-appearance: none;padding: 5px 15px;font-size:17px;'>"
                        . "<option>$exam ($count)</option>"
                        . "</select>"
                        . "<div class='overSelect'></div>"
                        . "</div>"
                    . "<div id='checkboxes$counter'>";
            $echostring2 = '';
            $loopcounter = 0;
            $stmt2 = $this->connect()->query("SELECT `system`, COUNT(*) AS `count` FROM questions WHERE exam = '$exam' GROUP BY `system`");
             while ($row2 = $stmt2->fetch()) {
                $system = $row2['system'];
                $count = $row2['count'];
                $echostringsub2 = "<label for='one$loopcounter'>"
                        . "<input type='checkbox' onclick='verstr($counter,$loopcounter);' id='vercheck$counter-$loopcounter'>"
                        . "<span>$system ($count)</span>"
                        . "</label>";
//                        "<input type='checkbox' onclick='verstr($exam,$system);' id='vercheck$exam-$system'>$system ($count)"
                $echostring2 .= $echostringsub2;
                $loopcounter +=1;
            }
            $finalechostring = $echostring1.$echostring2."</div>"."<div id='expanded$counter' style='display:none;'>false</div></td></tr>";
            echo $finalechostring;
            $counter += 1;
        }
        
    }
    public function getIncorrects(){
        $userid = $_SESSION["userid"];
        $color1 = "#002855";
        $color2 = "#EAAA00";
        $color = $color1;
        $answered = 'answered';
        $counter = 0;
        $stmt = $this->connect()->prepare("SELECT `exam`, COUNT(*) AS `count` FROM userattempts WHERE `correct_answer`= '0' AND `user_id` = ? GROUP BY `exam`");
        $stmt->execute([$userid]);
        if ($stmt->rowCount()){
            while ($row=$stmt->fetch()){
                $color == $color1 ? $color = $color2 : $color = $color1;
                $exam = $row['exam'];
                $count = $row['count'];       
                $echostring1 = "<tr><td style='width:150px'></td><td style='vertical-align:top;'>"
                        . "<input type='checkbox' onclick='examstr($counter);loadtable($answered);' id='exam$counter'></td>"
                        . "<td><div class='multiselect'>"
                        . "<div class='selectBox' onclick='showCheckboxes($counter)' style='background-color:transparent'>"
                            . "<select id='bean$counter' style='color:white;background-color:$color;-webkit-appearance: none;padding: 5px 15px;font-size:17px;'>"
                            . "<option>$exam ($count)</option>"
                            . "</select>"
                            . "<div class='overSelect'></div>"
                            . "</div>"
                        . "<div id='checkboxes$counter'>";
                $echostring2 = '';
                $loopcounter = 0;
                $stmt2 = $this->connect()->prepare("SELECT `system`,COUNT(*) AS `count` FROM userattempts WHERE `exam` = '$exam' AND `correct_answer`= '0' AND `user_id` = ? GROUP BY `system`");
        //                        $resultSet2 = $mysqli->query("SELECT `system`, COUNT(*) AS `count` FROM userattempts WHERE exam = '$exam' AND 'correct_answer'='0' GROUP BY `system`");
                $stmt2->execute([$userid]);
                if ($stmt2->rowCount()){
                    while ($row2 = $stmt2->fetch()) {
                        $system = $row2['system'];
                        $count = $row2['count'];
                        $echostringsub2 = "<label for='one$loopcounter'>"
                                . "<input type='checkbox' onclick='verstr($counter,$loopcounter);' id='vercheck$counter-$loopcounter'>"
                                . "<span>$system ($count)</span>"
                                . "</label>";
                        $echostring2 .= $echostringsub2;
                        $loopcounter +=1;
                    }
                }
                $finalechostring = $echostring1.$echostring2."</div>"."<div id='expanded$counter' style='display:none;'>false</div></td></tr>";
                echo $finalechostring;
                $counter += 1;
            }
        }
    }
    public function getUnanswered(){
        $userid = $_SESSION["userid"];
        $unanswered = 'unanswered';
        $counter = 0;
        $color1 = "#002855";
        $color2 = "#EAAA00";
        $color = $color1;
//        Shadeed webkit-appearance:none https://stackoverflow.com/questions/34543313/how-to-make-a-input-submit-button-with-flat-look
        $resultSet = $this->connect()->prepare("SELECT `exam`, COUNT(*) AS `count` FROM questions GROUP BY `exam`");
//        $resultSet = $this->connect()->query("SELECT `exam`, COUNT(*) AS `count` FROM questions GROUP BY `exam`");
        $resultSet->execute();
        if ($resultSet->rowCount()){
            while ($rows=$resultSet->fetch()){
                $color == $color1 ? $color = $color2 : $color = $color1;
                $exam = $rows['exam'];
                $count = $rows['count'];
//                        $diffquery = $mysqli->query("SELECT DISTINCT exam, COUNT(*) AS count "
//                                . "FROM alluserattempts WHERE exam = '$exam' AND `user_id` = '$userid' GROUP BY exam");
                $diffquery = $this->connect()->prepare("SELECT COUNT(DISTINCT question_id) AS qid, exam, COUNT(*) AS count FROM alluserattempts "
                        . "WHERE exam = '$exam' AND `user_id` = '$userid' GROUP BY question_id;");
                $diffquery->execute();
                while ($examdiff = $diffquery->fetch()) {
                    $diffcount = $examdiff['qid'];
                    $count -= $diffcount; 
                }
                if ($count===0 || $count<0){
                    $echostring1 = "<tr><td style='width:150px'></td><td style='vertical-align:top;'>"
                        . "<input type='checkbox' onclick='examstr($counter);loadtable($unanswered);' "
                            . "id='exam$counter' disabled></td>"
                        . "<td><div class='multiselect'>"
                        . "<div class='selectBox' onclick='showCheckboxes($counter)'>"
                        . "<select id='bean$counter' style='color:white;background-color:$color;"
                    . "-webkit-appearance: none;padding: 5px 15px;font-size:17px;'>"
                        . "<option>$exam (0)</option>"
                        . "</select>"
                        . "<div class='overSelect'></div>"
                        . "</div>"
                        . "<div id='checkboxes$counter'>";
                } else {
                    $echostring1 = "<tr><td style='width:150px'></td><td style='vertical-align:top;'>"
                        . "<input type='checkbox' onclick='examstr($counter);loadtable($unanswered);' id='exam$counter'></td>"
                        . "<td><div class='multiselect'>"
                        . "<div class='selectBox' onclick='showCheckboxes($counter)'>"
                        . "<select id='bean$counter' style='color:white;background-color:$color;"
                    . "-webkit-appearance: none;padding: 5px 15px;font-size:17px;'>"
                        . "<option>$exam ($count)</option>"
                        . "</select>"
                        . "<div class='overSelect'></div>"
                        . "</div>"
                        . "<div id='checkboxes$counter'>";
                }
                $echostring2 = '';
                $loopcounter = 0;
                $resultSet2 = $this->connect()->prepare("SELECT DISTINCT `system`, "
                    . "COUNT(*) AS `count` "
                    . "FROM questions "
                    . "WHERE `exam` = '$exam'"
                    . "GROUP BY `system`");
//                        $resultSet2 = $mysqli->query("SELECT `system`, COUNT(*) AS `count` FROM userattempts WHERE exam = '$exam' AND 'correct_answer'='0' GROUP BY `system`");
                $resultSet2->execute();
                while ($rows2 = $resultSet2->fetch()) {
                    $system = $rows2['system'];
                    $count = $rows2['count'];
//                            $diffquery2 = $mysqli->query("SELECT system, COUNT(*) AS count "
//                                    . "FROM alluserattempts WHERE system = '$system' AND `user_id` = '$userid' GROUP BY system");
                    $diffquery2 = $this->connect()->prepare("SELECT COUNT(DISTINCT question_id) AS qid, system, COUNT(*) AS count FROM alluserattempts "
                            . "WHERE system = '$system' AND `user_id` = '$userid' GROUP BY question_id;");
                    $diffquery2->execute();
                    while ($examdiff2 = $diffquery2->fetch()) {
                        $diffcount2 = $examdiff2['qid'];
                        $count -= $diffcount2;
                    }
                    if ($count===0 || $count<0){
                        $echostringsub2 = "<label for='one$loopcounter'>"
                            . "<input type='checkbox' onclick='verstr($counter,$loopcounter);' id='vercheck$counter-$loopcounter' disabled>"
                            . "<span >$system (0)</span>"
                            . "</label>";
                    } else {
                       $echostringsub2 = "<label for='one$loopcounter'>"
                            . "<input type='checkbox' onclick='verstr($counter,$loopcounter);' id='vercheck$counter-$loopcounter'>"
                            . "<span>$system ($count)</span>"
                            . "</label>"; 
                    }

//                        "<input type='checkbox' onclick='verstr($exam,$system);' id='vercheck$exam-$system'>$system ($count)"
                    $echostring2 .= $echostringsub2;
                    $loopcounter +=1;
                }
                $finalechostring = $echostring1.$echostring2."</div>"."<div id='expanded$counter' style='display:none;'>false</div></td></tr>";
                echo $finalechostring;
                $counter += 1;  
            }
        }
    }
    public function getMarked(){
        $userid = $_SESSION["userid"];
        $marked = 'marked';
        $counter = 0;
        $color1 = "#002855";
        $color2 = "#EAAA00";
        $color = $color1;
        $resultSet = $this->connect()->prepare("SELECT `exam`, COUNT(*) AS `count` FROM alluserattempts WHERE `marked`= '1' AND `user_id` = $userid GROUP BY `exam`");
        $resultSet->execute();
        if ($resultSet->rowCount()){
            while ($rows=$resultSet->fetch()){
                $color == $color1 ? $color = $color2 : $color = $color1;
                $exam = $rows['exam'];
                $count = $rows['count'];       
                $echostring1 = "<tr><td style='width:150px'></td><td style='vertical-align:top;'>"
                        . "<input type='checkbox' onclick='examstr($counter);loadtable($marked);' id='exam$counter'></td>"
                        . "<td><div class='multiselect'>"
                        . "<div class='selectBox' onclick='showCheckboxes($counter)'>"
                            . "<select id='bean$counter' style='color:white;background-color:$color;"
                    . "-webkit-appearance: none;padding: 5px 15px;font-size:17px;'>"
                            . "<option>$exam ($count)</option>"
                            . "</select>"
                            . "<div class='overSelect'></div>"
                            . "</div>"
                        . "<div id='checkboxes$counter'>";
                $echostring2 = '';
                $loopcounter = 0;
    //                        $resultSet2 = $mysqli->query("SELECT `system`, "
    //                            . "COUNT(*) AS `count` "
    //                            . "FROM userattempts "
    //                            . "WHERE `exam` = '$exam'"
    //                            . "AND `correct_answer`= '0'"
    //                            . "AND `user_id` = $userid"
    //                            . "GROUP BY `system`");
                $resultSet2 = $this->connect()->prepare("SELECT `system`,COUNT(*) AS `count` FROM alluserattempts WHERE `exam` = '$exam' AND `marked`= '1' AND `user_id` = '$userid' GROUP BY `system`");
    //                        $resultSet2 = $mysqli->query("SELECT `system`, COUNT(*) AS `count` FROM userattempts WHERE exam = '$exam' AND 'correct_answer'='0' GROUP BY `system`");
                $resultSet2->execute();
                while ($rows2 = $resultSet2->fetch()) {
                    $system = $rows2['system'];
                    $count = $rows2['count'];
                    $echostringsub2 = "<label for='one$loopcounter'>"
                            . "<input type='checkbox' onclick='verstr($counter,$loopcounter);' id='vercheck$counter-$loopcounter'>"
                            . "<span>$system ($count)</span>"
                            . "</label>";
    //                        "<input type='checkbox' onclick='verstr($exam,$system);' id='vercheck$exam-$system'>$system ($count)"
                    $echostring2 .= $echostringsub2;
                    $loopcounter +=1;
                }
                $finalechostring = $echostring1.$echostring2."</div>"."<div id='expanded$counter' style='display:none;'>false</div></td></tr>";
                echo $finalechostring;
                $counter += 1;  
            }
        }
    }
}

