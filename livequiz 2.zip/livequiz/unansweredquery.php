<?php
session_start();
include "loginstuff/access.php";
access();
$userid = $_SESSION["userid"];
//SELECT * FROM `questions` WHERE question_number NOT IN (SELECT DISTINCT question_id FROM alluserattempts);

$requestPayload = file_get_contents("php://input");
$object = json_decode($requestPayload);
$remexam = rtrim($object[1], ", ");
$remsys = rtrim($object[3], ", ");

$itrexam = (explode(',',$object[1])); 
$itrsys = (explode(',',$object[3]));

$noquestoget = $object[5];
$rowlen = substr_count($object[3], ',');
//https://stackoverflow.com/questions/16162719/counting-the-number-of-specific-characters-inside-string

$dbhost = "localhost";
$dbuser = "root";
$dbpass = "";
$dbname = "demoquestions";
$connection = mysqli_connect($dbhost, $dbuser, $dbpass, $dbname);
$len = $noquestoget;
$counter = $len;
$data = array();
$explanation = array();
$options = array();
$exparr = array();
for ($x=0; $x<$noquestoget; $x++){
    array_push($exparr,1000000);
    $index = ($len-$counter)%$rowlen;
    $counter -= 1;
    $whilecounter = 0;
    $examtouse = $itrexam[$index];
    $systouse = $itrsys[$index];
//    echo json_encode($examtouse);
//    echo json_encode($systouse);
//https://stackoverflow.com/questions/1519272/mysql-not-in-query
//https://stackoverflow.com/questions/34312757/mysql-select-unique-value
    //added WHERE user_id='$userid' to question_query
    $question_query = "SELECT  * 
    FROM    `questions`
    WHERE   `exam` IN (".$examtouse.")
    AND     `system` IN (".$systouse.")
    AND     `question_number` NOT IN (SELECT DISTINCT question_id FROM alluserattempts WHERE user_id='$userid')
    ORDER BY RAND()
    LIMIT       1";
    $que_query_run = mysqli_query($connection,$question_query);
    $row3 = mysqli_fetch_assoc($que_query_run);
    array_push($data, $row3);
    $exptoget = $row3['question_number'];
    array_push($exparr,$row3['question_number']);
    $explanation_query = "SELECT  * 
    FROM    `explanations` 
    WHERE   `explanation_number` IN (".$exptoget.")";
    $exp_query_run = mysqli_query($connection, $explanation_query);
    $row4 = mysqli_fetch_assoc($exp_query_run);
    array_push($explanation, $row4);
    $option_query = "SELECT  * 
    FROM    `options` 
    WHERE   `question_number` IN (".$exptoget.")";
    $opt_query_run = mysqli_query($connection, $option_query);
    while ($row5 = mysqli_fetch_assoc($opt_query_run)){
        array_push($options, $row5);
    }
}
$suparr = array();
array_push($suparr,$data);
array_push($suparr,$explanation);
array_push($suparr,$options);

echo json_encode($suparr);
//echo json_encode($data);
//echo json_encode($explanation);
//echo json_encode($options);
//AND     `system` IN (".implode(',',$newarr).")
//AND     `system` IN ('$newsystem')
//$connection = mysqli_connect($dbhost, $dbuser, $dbpass, $dbname);
//$email = $object[5];
//
//$question_query = "SELECT  * 
//FROM    `questions`
//WHERE   `exam` IN (".$remexam.")
//AND     `system` IN (".$remsys.")
//ORDER BY RAND()
//LIMIT       ". $email . "";
//$que_query_run = mysqli_query($connection,$question_query);
//$data = array();
//
//$counter = 0;
//$exparr = array();
//while ($row3 = mysqli_fetch_assoc($que_query_run))
//{
//    array_push($data, $row3);
//    array_push($exparr,$data[$counter]['question_number']);
//    $counter+=1;
//}
//$explanation_query = "SELECT  * 
//FROM    `explanations` 
//WHERE   `explanation_number` IN (".implode(',',$exparr).")";
//$exp_query_run = mysqli_query($connection, $explanation_query);
//$explanation = array();
//while ($row4 = mysqli_fetch_assoc($exp_query_run))
//{
//    array_push($explanation, $row4);
//}
//
//$option_query = "SELECT  * 
//FROM    `options` 
//WHERE   `question_number` IN (".implode(',',$exparr).")";
//$opt_query_run = mysqli_query($connection, $option_query);
//$options = array();
//while ($row5 = mysqli_fetch_assoc($opt_query_run))
//{
//    array_push($options, $row5);
//}
//$suparr = array();
//array_push($suparr,$data);
//array_push($suparr,$explanation);
//array_push($suparr,$options);
//
//echo json_encode($suparr);
//
//echo json_encode($data);
//echo json_encode($explanation);
?>
