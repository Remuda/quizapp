<html>
<head>
<!--<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js" integrity="sha384-7+zCNj/IqJ95wo16oMtfsKbZ9ccEh31eOz1HGyDuCQ6wgnyJNSYdrPa03rtR1zdB" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js" integrity="sha384-QJHtvGhmr9XOIpI6YVutG+2QOK9T+ZnN4kzFN1RtK3zEFEIsxhlmWl5/YESvpZ13" crossorigin="anonymous"></script>-->
</head>




<?php
//$result = mysqli_query($connection, "SELECT * FROM questions WHERE question_number NOT IN (SELECT question_number FROM userattempts) order by RAND() LIMIT 2");  
//$result = mysqli_query($connection,"SELECT * FROM questions WHERE question_id NOT IN (SELECT question_number FROM student_answers WHERE student_id = '5') ORDER BY RAND() LIMIT 10");    
//assumptions: questions holds all the questions; student answers holds student specific answers; student holds student info
//student_id is the primary key of student table and foreign key of student_answer table; student_id is brought from session or somewhere
//https://www.youtube.com/watch?v=gAB2SK0PPTE
//https://stackoverflow.com/questions/8200189/select-random-row-from-sql-using-php
//rand is very slow in mysql, use a random number column, generate random numbers and pick the row with the closest higher value
// https://stackoverflow.com/questions/18917235/using-array-values-in-mysql-query
//https://www.sitepoint.com/community/t/using-an-array-in-a-mysql-query/5745 (dynamic array in mysql query)
//https://www.youtube.com/watch?v=DS6z2RcsbFg dynamic with other column filtering like exam 1 has no ent questions
$requestPayload = file_get_contents("php://input");
$object = json_decode($requestPayload);
//$conn = mysqli_connect("localhost","root","","demoquestions");
//var_dump($object);
//var_dump($object[5]);
//var_dump(explode(',',$object[5]));
//var_dump(explode(',',$object[7]));
$arr = $object[3];
$remove = rtrim($object[3], ", ");
//https://stackoverflow.com/questions/5592994/remove-the-last-character-from-a-string
//echo "$object[7]<br>";
//echo "$remove<br>";
$newarr=explode(',',$remove);
//print_r($newarr[1]);
//echo gettype($object[7]);
//echo gettype($remove);
//echo gettype($newarr);
//echo (explode(',',$remove));
$dbhost = "localhost";
$dbuser = "root";
$dbpass = "";
$dbname = "demoquestions";
$startDT =$object[1];
$cars=$newarr;
$bars = 2;
$nums = 2;
$connection = mysqli_connect($dbhost, $dbuser, $dbpass, $dbname);
$email = $object[5];
//https://www.toolbox.com/tech/enterprise-software/question/pass-array-to-in-in-a-where-clause-in-an-sql-query-120514/
//https://stackoverflow.com/questions/4037145/mysql-how-to-select-rows-where-value-is-in-array
//https://www.sitepoint.com/community/t/using-an-array-in-a-mysql-query/5745
//https://stackoverflow.com/questions/23178816/mysql-dynamic-query-in-stored-procedure
//$question_query = "SELECT * FROM questions WHERE question_number NOT IN (SELECT question_number FROM userattempts) order by RAND() LIMIT 10";  
//(".implode(',', $friendid).")
$question_query = "SELECT  `question_number`,
        `question_text`,
        COUNT( * ) AS `total` 
FROM    `questions` 
WHERE   `exam` IN ('$startDT') 
AND     `system` IN (".implode(',',$newarr).")
GROUP BY    `question_number`,
            `exam`
LIMIT       ". $email . "";
//AND     `system` IN (1,2)
//AND     `system` IN ('$cars','$bars')
//WHERE   `exam` BETWEEN '$startDT' AND '$endDT' 
//$question_query = "SELECT  `question_number`,
//https://stackoverflow.com/questions/14451364/php-code-for-display-10-records-from-mysql-dynamically
$que_query_run = mysqli_query($connection,$question_query);

while ($row = mysqli_fetch_assoc($que_query_run)) {
    echo "{$row['question_number']}<p> </p>{$row['question_text']}<br>";
}
//print_r($row);
?>
</html>