<?php  
//fix auto increment/primary key of table https://stackoverflow.com/questions/1809893/how-to-reset-the-primary-key-of-a-table
//fix primary key for existing values https://stackoverflow.com/questions/740358/reorder-reset-auto-increment-primary-key
//HTML text fomatting https://www.bitdegree.org/learn/html-text-formatting
// Prevent screenshot https://stackoverflow.com/questions/3130983/stop-user-from-using-print-scrn-printscreen-key-of-the-keyboard-for-any-we
// Prevent screenshot https://stackoverflow.com/questions/26296882/how-to-disable-printscreen-with-javascript
// Prevent screenshot https://stackoverflow.com/questions/2176861/javascript-get-clipboard-data-on-paste-event-cross-browser
// Limit number of devices https://security.stackexchange.com/questions/36140/how-to-restrict-access-to-a-web-application-to-authorized-devices-only
include 'db.php';
if(isset($_POST['submit'])){
	$question_number = $_POST['question_number'];
	$question_text = $_POST['question_text'];
	$correct_choice = $_POST['correct_choice'];
        $explanation_number = $_POST['explanation_number'];
        $explanation_text = $_POST['explanation_text'];
        $exam_text = $_POST['exam'];
        $system_text = $_POST['system'];
        $question_image = $_POST['questionimage'];
	// Choice Array
	$choice = array();
	$choice[1] = $_POST['choice1'];
	$choice[2] = $_POST['choice2'];
	$choice[3] = $_POST['choice3'];
	$choice[4] = $_POST['choice4'];
	$choice[5] = $_POST['choice5'];
        // Explanation Array
        $explanation = array();
        $explanation[1] = $_POST['explanation_text'];

 // First Query for Questions Table

	$query = "INSERT INTO questions (";
	$query .= "question_number, question_text, exam, system, question_image )";
	$query .= "VALUES (";
	$query .= " '{$question_number}','{$question_text}','{$exam_text}','{$system_text}','{$question_image}' ";
	$query .= ")";

	$result = mysqli_query($connection,$query);
	
	//Validate First Query
	if($result){
		foreach($choice as $option => $value){
			if($value != ""){
				if($correct_choice == $option){
					$is_correct = 1;
				}else{
					$is_correct = 0;
				}
			


				//Second Query for Choices Table
                                //option is a reserved mysql word, using coption instead
				$query = "INSERT INTO options (";
				$query .= "question_number,is_correct,coption)";
				$query .= " VALUES (";
				$query .=  "'{$question_number}','{$is_correct}','{$value}' ";
				$query .= ")";

				$insert_row = mysqli_query($connection,$query);
				// Validate Insertion of Choices

				if($insert_row){
					continue;
				}else{
					die("2nd Query for Choices could not be executed" . $query);
					
				}

			}
		}
		$message = "Question has been added successfully";
	}
        if($insert_row){
            foreach ($explanation as $eoption => $evalue) {
            if ($evalue != "") {

                //Third Query for Explanation Table
                $query = "INSERT INTO explanations (";
                $query .= "explanation_number,explanation_text)";
                $query .= " VALUES (";
                $query .= "'{$explanation_number}','{$evalue}' ";
                $query .= ")";

                $insert_exp = mysqli_query($connection, $query);
                // Validate Insertion of Choices

                if ($insert_exp) {
                    continue;
                } else {
                    die("3rd Query for Explanations could not be executed" . $query);
                }
            }
        }
        $message = "Explanation has been added successfully";
    }
        

	




}

		$query = "SELECT * FROM questions";
		$questions = mysqli_query($connection,$query);
		$total = mysqli_num_rows($questions);
		$next = $total+1;
		

?>
<html>
<head>
	<title>PHP Quizer</title>
	<link rel="stylesheet" type="text/css" href="css/style.css">
</head>
<body>

	<header>
		<div class="container">
			<p>PHP Quizer</p>
		</div>
	</header>

	<main>
			<div class="container">
				<h2>Add A Question</h2>
				<?php if(isset($message)){
					echo "<h4>" . $message . "</h4>";
				} ?>
								
				<form method="POST" action="add.php">
						<p>
							<label>Question Number:</label>
							<input type="number" name="question_number" value="<?php echo $next;  ?>">
						</p>
                                                <p>
							<label>Explanation Number:</label>
							<input type="number" name="explanation_number" value="<?php echo $next;  ?>">
						</p>
						<p>
							<label>Question Text:</label>
							<input type="text" name="question_text">
						</p>
                                                <p>
							<label>Explanation Text:</label>
							<input type="text" name="explanation_text">
						</p>
						<p>
							<label>Choice 1:</label>
							<input type="text" name="choice1">
						</p>
						<p>
							<label>Choice 2:</label>
							<input type="text" name="choice2">
						</p>
						<p>
							<label>Choice 3:</label>
							<input type="text" name="choice3">
						</p>
						<p>
							<label>Choice 4:</label>
							<input type="text" name="choice4">
						</p>
						<p>
							<label>Choice 5:</label>
							<input type="text" name="choice5">
						</p>
						<p>
							<label>Correct Option Number</label>
							<input type="number" name="correct_choice">
						</p>
                                                <p>
							<label>Exam</label>
							<input type="text" name="exam">
						</p>
                                                <p>
							<label>System</label>
							<input type="text" name="system">
						</p>
                                                <p>
							<label>Question Image</label>
							<input type="text" name="questionimage">
						</p>
						<input type="submit" name="submit" value ="submit">


				</form>
			</div>

	</main>


	<footer>
			<div class="container">
				Copyright &copy; ARIZ Exams
			</div>


	</footer>








</body>
</html>