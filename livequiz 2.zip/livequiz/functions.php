<?php

function e($value){
    return htmlspecialchars($value, ENT_QUOTES, 'utf-8');
}

