<?php
    session_start();
    include "loginstuff/access.php";
    access();
    $userid = '';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Exam Analysis</title>
<header class="header-fixed">
	<div class="header-limiter">
		<h1><a href="#">ADAPTIVE<span>Test Bank</span></a></h1>
		<nav>
                    <a href="../quiz/loginstuff/windex.php" style="color:#EAAA00"><b>Home</b></a>
                    <a href="selectpastexam.php" style="color:#5383d3"><b>Student Exams</b></a>
                    <a href="selectdata4.php" style="color:#EAAA00" name="submit"><b>Add Questions</b></a>
                    <a href="#" style="color:#5383d3"><b>|</b></a>
                        <?php
                            if(isset($_SESSION["userid"])){
                        ?>
                    <a href="#" style="color:#5383d3"><b><?php echo $_SESSION["useruid"]; ?></b></a>
                    <a href="../quiz/loginstuff/includes/logout.inc.php" class="header-login-a" style="color:#EAAA00"><b>Log Out</b></a>
                        <?php
                            }
                            else
                            {
                        ?>
                            <a href="#" style="color:#5383d3"><b>Sign Up</b></a>
                            <a href="#" class="header-login-a" style="color:#EAAA00"><b>Log In</b></a>
                        <?php
                        }
                        ?>
		</nav>
	</div>
</header>
<style>
.header-fixed {
	background-color:#292c2f;
	box-shadow:0 1px 1px #ccc;
	padding: 20px 40px;
	height: 80px;
	/*color: #A2AAAD;*/
	box-sizing: border-box;
	top:-100px;

	-webkit-transition:top 0.3s;
	transition:top 0.3s;
}

.header-fixed .header-limiter {
	max-width: 1200px;
	text-align: center;
	margin: 0 auto;
        /*color:#A2AAAD;*/
}

/*	The header placeholder. It is displayed when the header is fixed to the top of the
	browser window, in order to prevent the content of the page from jumping up. */

.header-fixed-placeholder{
	height: 80px;
	display: none;
}


.header-fixed .header-limiter h1 {
	float: left;
	font: normal 28px Cookie, Arial, Helvetica, sans-serif;
	line-height: 40px;
	margin: 0;
}

.header-fixed .header-limiter h1 span {
	color: #5383d3;
}

/* The navigation links */

.header-fixed .header-limiter a {
	color: #EAAA00;
	text-decoration: none;
}

.header-fixed .header-limiter nav {
	font:16px Arial, Helvetica, sans-serif;
	line-height: 40px;
	float: right;
}

.header-fixed .header-limiter nav a{
	display: inline-block;
	padding: 0 5px;
	text-decoration:none;
	color: #ffffff;
	opacity: 0.9;
}

.header-fixed .header-limiter nav a:hover{
	opacity: 1;
}

.header-fixed .header-limiter nav a.selected {
	color: #608bd2;
	pointer-events: none;
	opacity: 1;
}

/* Fixed version of the header */

body.fixed .header-fixed {
	padding: 10px 40px;
	height: 50px;
	position: fixed;
	width: 100%;
	top: 0;
	left: 0;
	z-index: 1;
}

body.fixed .header-fixed-placeholder {
	display: block;
}

body.fixed .header-fixed .header-limiter h1 {
	font-size: 24px;
	line-height: 30px;
}

body.fixed .header-fixed .header-limiter nav {
	line-height: 28px;
	font-size: 13px;
}


/* Making the header responsive */

@media all and (max-width: 600px) {

	.header-fixed {
		padding: 20px 0;
		height: 75px;
	}

	.header-fixed .header-limiter h1 {
		float: none;
		margin: -8px 0 10px;
		text-align: center;
		font-size: 24px;
		line-height: 1;
	}

	.header-fixed .header-limiter nav {
		line-height: 1;
		float:none;
	}

	.header-fixed .header-limiter nav a {
		font-size: 13px;
	}

	body.fixed .header-fixed {
		display: none;
	}

}

/*
	 We are clearing the body's margin and padding, so that the header fits properly.
	 We are also adding a height to demonstrate the scrolling behavior. You can remove
	 these styles.
 */

body {
	margin: 0;
	padding: 0;
	height: 1500px;
}    

</style>  


<script>
function genexam(num){
    const jsondict = JSON.stringify(num);
    const xhr = new XMLHttpRequest();
    xhr.open("POST","pastexamquery.php",true);
    xhr.send(jsondict);
    xhr.onload = () => {
        var data = JSON.parse(xhr.responseText);
        console.log(data);
        localStorage.setItem('data',JSON.stringify(data));
    }
    window.setInterval(nextpage, 1000);
}
function nextpage(){
//    window.setInterval(nextpage, 1000);
    window.location.href='pastexampicslider.php';
}
</script>

</head>
<body>
    <table class="row" id="examandsystems">
        <tr style="height:50px"><td></td><td></td><td></td></tr>
                <?php
                $userid = $_SESSION["userid"];
                $all = 'all';
                $dbhost = "localhost";
                $dbuser = "root";
                $dbpass = "";
                $dbname = "demoquestions";
                $counter = 0;
                $mysqli = NEW MySQLi($dbhost, $dbuser, $dbpass, $dbname);
                $noofids = 0;
                $counter = 0;
                $perccorr = "SELECT COUNT(correct_answer) FROM `alluserattempts` WHERE user_id = 2 AND correct_answer=1;";
                $resultSet = $mysqli->query("SELECT DISTINCT user_id FROM `alluserattempts`;");
                while ($rows = $resultSet->fetch_assoc()) {
                    $noofids +=1;
                    $idtouse=$rows['user_id'];
                    $noexamstaken = $mysqli->query("SELECT COUNT(DISTINCT exam_number) as 'count' FROM alluserattempts WHERE user_id = '$idtouse';");
                    $rhyme = $noexamstaken->fetch_assoc();
                    $totexams = $rhyme['count'];
                    $totright = $mysqli->query("SELECT COUNT(correct_answer) AS `countc` FROM `alluserattempts` WHERE user_id = $idtouse AND correct_answer=1;");
                    $rhyme1 = $totright->fetch_assoc();
                    $totcorr = $rhyme1['countc'];
                    $totattempted = $mysqli->query("SELECT COUNT(correct_answer) AS `countt` FROM `alluserattempts` WHERE user_id = $idtouse;");
                    $rhyme2 = $totattempted->fetch_assoc();
                    $totques = $rhyme2['countt'];
                    $uniqueques = $mysqli->query("SELECT COUNT(DISTINCT question_id) AS `countu` FROM `alluserattempts` WHERE user_id=$idtouse;");
                    $rhyme3 = $uniqueques->fetch_assoc();
                    $nouniqueques = $rhyme3['countu'];
                    $percentcorr = floor((intval($totcorr)/intval($totques))*100);
                    
                    $echostring1 = "<tr><td style='width:150px'></td><td style='display:none'>".$percentcorr."</td><td style='vertical-align:top;'>"
                            . "<button type='button' id='test$counter' style='color:black;padding:5px 15px;background-color:transparent;font-size:17px;border:none;border-radius:5px;width:800px;'>"
                            . "Student ".$idtouse." | Total Exams: ".$totexams." | Percent Correct: ".$percentcorr." %  of ".$nouniqueques."  Qs</button></td>";
                    $echostring2 = '';
                    $finalechostring = $echostring1.$echostring2."</div>"."<div id='expanded$counter' style='display:none;'>false</div></td></tr>";
                    echo $finalechostring;
                    $counter+=1;
                }


                ?>  
    </table> 
</body>
<script>
//    W3 schools sort table https://www.w3schools.com/howto/howto_js_sort_table.asp
function sortTable() {
  var table, rows, switching, i, x, y, shouldSwitch;
  table = document.getElementById("examandsystems");
  switching = true;
  /* Make a loop that will continue until
  no switching has been done: */
  while (switching) {
    // Start by saying: no switching is done:
    switching = false;
    rows = table.rows;
    /* Loop through all table rows (except the
    first, which contains table headers): */
    for (i = 1; i < (rows.length - 1); i++) {
      // Start by saying there should be no switching:
      shouldSwitch = false;
      /* Get the two elements you want to compare,
      one from current row and one from the next: */
      x = rows[i].getElementsByTagName("TD")[1];
      y = rows[i + 1].getElementsByTagName("TD")[1];
      // Check if the two rows should switch place:
//      if (x.innerHTML.toLowerCase() > y.innerHTML.toLowerCase()) {
        if (parseInt(x.innerHTML) < parseInt(y.innerHTML)) {
        // If so, mark as a switch and break the loop:
        shouldSwitch = true;
        break;
      }
    }
    if (shouldSwitch) {
      /* If a switch has been marked, make the switch
      and mark that a switch has been done: */
      rows[i].parentNode.insertBefore(rows[i + 1], rows[i]);
      switching = true;
    }
  }
  for (var x=1; x<rows.length;x++){
      rows = table.rows;
      if (x%2==0){
          document.getElementById("examandsystems").rows[x].getElementsByTagName("TD")[2].style.backgroundColor= "#EAAA00";
          document.getElementById("examandsystems").rows[x].getElementsByTagName("TD")[2].style.borderRadius= "5px";
//          #5383d3#EAAA00
      } else {
//          rows[x].getElementsByTagName("TD")[1].style.backgroundColor= "green";
            document.getElementById("examandsystems").rows[x].getElementsByTagName("TD")[2].style.backgroundColor= "#5383d3";
            document.getElementById("examandsystems").rows[x].getElementsByTagName("TD")[2].style.borderRadius= "5px";
      }
      //document.getElementById("examandsystems").getElementsByTagName("TD")[1].style.backgroundColor="black
  }
}
sortTable();
</script>
</html>
