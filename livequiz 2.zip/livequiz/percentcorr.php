<?php
session_start();
include "loginstuff/access.php";
access();
$userid = $_SESSION["userid"];
//Multiple queries in one https://stackoverflow.com/questions/888731/two-sql-count-queries
$dbhost = "localhost";
$dbuser = "root";
$dbpass = "";
$dbname = "demoquestions";

$connection = mysqli_connect($dbhost, $dbuser, $dbpass, $dbname);
$querycount = "SELECT
   (SELECT COUNT(*) FROM alluserattempts) AS 'TotalCount',
   (SELECT COUNT(*) FROM alluserattempts WHERE (correct_answer=0) AND (user_id=$userid)) AS Incorr,
   (SELECT COUNT(*) FROM alluserattempts WHERE (correct_answer=1) AND (user_id=$userid)) AS Corr,
   (SELECT COUNT(*) FROM alluserattempts WHERE (correct_answer=9) AND (user_id=$userid)) AS Blank";
$result = mysqli_query($connection,$querycount);    
$examcounts = array();
while ($row = mysqli_fetch_assoc($result))
{
    array_push($examcounts, $row['Incorr']);
    array_push($examcounts, $row['Corr']);
    array_push($examcounts, $row['Blank']);
}

echo json_encode($examcounts);
//echo json_encode($edata);
exit();

?>