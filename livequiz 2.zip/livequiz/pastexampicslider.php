<?php
    session_start();
    include "loginstuff/access.php";
    access();
?>
<script>
    //User this character ("•") in marking which question the user is currently on
    var lastexamnum = 0;
    var ajax = new XMLHttpRequest();
    ajax.open("GET", "lastexamno.php", true);
    ajax.send();
    ajax.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
        var data = JSON.parse(this.responseText);
//        document.getElementById("lastexamnumber").innerHTML=data;
        lastexamnum = parseInt(data);
        }
    };
    var combdata = [];
    var questionids = [];
    function getdata(){
        var predata = localStorage.getItem('data');
        combdata = JSON.parse(predata);
        var qdata = combdata[0];
        console.log(qdata);
        var qcolumn = "";
        var questiono = "";
        var examno = "";
        var systemno = "";
        var qidno = "";
        var que_img = "";
        var datalen = qdata.length;
        for (var a=0; a< qdata.length; a++){
//        for (var a=0; a< 4; a++){
            qcolumn += "<tr>";
                qcolumn += "<td>";
//                qcolumn+="<a href=\'#\' id=\'queb"+a+"\' onClick=\'onefunction("+a+")\'>•Q"+(a+1);
                qcolumn+="<a href=\'javascript\:\;\' id=\'queb"+a+"\' onClick=\'onefunction("+a+")\'>Q"+(a+1);
//                a href="javascript:;"
                qcolumn+="</a>";
                qcolumn+="</td>";
            qcolumn += "</tr>";

            questiono += "<div id=\'question"+a+"\'>";
            questiono += "</div>";
            
            examno += "<div id=\'exam"+a+"\'>";
            examno += "</div>";
            
            systemno += "<div id=\'system"+a+"\'>";
            systemno += "</div>";
            
            qidno += "<div id=\'qidno"+a+"\'>";
            qidno += "</div>";
            que_img += "<img src=\'\' name=\'questionimg\' id=\'queimg"+a+"\'>";
//            que_img += "<img src=\'\' name=\'questionimg\' width=\'451\' height=\'587\' id=\'queimg"+a+"\'>";
//            que_img += "</div>";

        }
        document.getElementById("sideLine").innerHTML += qcolumn;
        document.getElementById("quebox").innerHTML += questiono;
        document.getElementById("imgbox").innerHTML += que_img;
        document.getElementById("exambox").innerHTML += examno;
        document.getElementById("systembox").innerHTML += systemno;
        document.getElementById("qidbox").innerHTML += qidno;
        for (var ab=0; ab<datalen; ab++){
//        for (var ab=0; ab<4; ab++){
            document.getElementById("question"+ab).innerHTML = qdata[ab].question_text;
            document.getElementById("question"+ab).style.display="none";
            document.getElementById("exam"+ab).innerHTML = qdata[ab].exam;
            document.getElementById("exam"+ab).style.display="none";
            document.getElementById("system"+ab).innerHTML = qdata[ab].system;
            document.getElementById("system"+ab).style.display="none";
            document.getElementById("qidno"+ab).innerHTML = qdata[ab].question_number;
            //https://stackoverflow.com/questions/4539019/how-to-change-attribute-in-html-using-javascript
            document.getElementById("queimg"+ab).style.display="none";
            document.getElementById("queimg"+ab).src = qdata[ab].question_image;
            questionids.push(qdata[ab].question_number);
//            if (questionids.includes(qdata[ab].question_number)==='false'){
//                questionids.push(qdata[ab].question_number);
//            }
            document.getElementById("qidno"+ab).style.display="none";
        }
        document.getElementById("question0").style.display="block";
        if (document.getElementById("queimg0").src!==window.location.href){
            document.getElementById("queimg0").style.display="block";
        }
    }
    function getexp(){
        var edata = combdata[1];
        console.log(edata);
        var subbo = "";
        var explano = "";
        var exp_img = "";
        var styles = "";
        var edatalen = edata.length;
        for (var b=0; b< edata.length; b++){
            
            subbo += "<div id=\'subbutton"+b+"\'>";
                subbo += "<button type=\'button\' id=\'subton"+b+"\' onClick=\'twofunction("+b+")\' style=\'display\:none\'>";
                subbo += "Submit";
                subbo += "</button>";
            subbo += "</div>";
                
                
            explano += "<div id=\'explanation"+b+"\'>";
            explano += "</div>";
            
//            exp_img += "<img src=\'\' name=\'explanationimg\' width=\'451\' height=\'587\' id=\'expimg"+b+"\'>";
            exp_img += "<tr><td><a id=\'home"+b+"\' href=\'javascript\:\;\'>";
            exp_img += "<img class=\'image_on\' src=\'\'alt=\'logo\' width=\'451\' height=\'587\' id=\'expimga"+b+"\'>";
            exp_img += "<img class=\'image_off\' src=\'\' alt=\'logo\' width=\'451\' height=\'587\' id=\'expimgb"+b+"\'>";
            exp_img += "</a></td></tr>";
            
            styles += `
            .image_off, #home`+b+`\:hover .image_on{
                display:none
            }
            .image_on, #home`+b+`\:hover .image_off{
                display:block
            }
            `
        }
        document.getElementById("subbox").innerHTML += subbo;
        document.getElementById("expbox").innerHTML += explano;
        document.getElementById("expimage").innerHTML += exp_img;
        var styleSheet = document.createElement("style");
        styleSheet.type = "text/css";
        styleSheet.innerText += styles;
        document.head.appendChild(styleSheet);
        for (var bb=0; bb<edatalen; bb++){
//        for (var bb=0; bb<4; bb++){
            document.getElementById("explanation"+bb).innerHTML = edata[bb].explanation_text;
            document.getElementById("expimga"+bb).src = document.getElementById("queimg"+bb).src;
            document.getElementById("expimgb"+bb).src = edata[bb].exp_image;
            document.getElementById("explanation"+bb).style.display="none";
            document.getElementById("home"+bb).style.display="none";
//            document.getElementById("expimga"+bb).style.display="none";
//            document.getElementById("expimgb"+bb).style.display="none";
            document.getElementById("subbutton"+bb).style.display="none";   
        }
        document.getElementById("subbutton0").style.display="block";
    }
    
    function getopts(){
        var cdata = combdata[2];
        console.log(cdata);
        var clen = cdata.length;
        for (var c=0; c<cdata.length; c++) {
            var cslice = cdata[c].question_number;
            document.getElementById("cslice").innerHTML += cslice + ",";
            var cops = cdata[c].coption;
            document.getElementById("cops").innerHTML += cops + ",";
            var corrects = cdata[c].is_correct;
            document.getElementById("corrects").innerHTML += corrects + ",";
        }
        
        for (var c=0; c< cdata.length ; c++) {
            var k=0;
            if (cdata[k].question_number===cdata[c].question_number){
                document.getElementById("fernsub"+c).innerHTML=cdata[c].coption;
                document.getElementById("fern"+c).style.display = 'table-row';
                document.getElementById("fernsub"+c).style.display = 'inline';
                
//                if (cdata[c].is_correct==="1"){
//                    document.getElementById("answerkey").innerHTML += "s0,a"+c+",";
//                }
                k+=1;                
            } else {
                break;
            }
        }
        var mr=0
        var windex = 0;
        for (var mc=0; mc<(clen-1) ; mc++) {
            var mca = mc+1;
            mr += 1;
            if (cdata[mc].is_correct==="1"){
//                document.getElementById("answerkey").innerHTML += "s"+(parseInt(cdata[mc].question_number)-1)+"a"+(mr-1)+",";
                document.getElementById("answerkey").innerHTML += "s"+windex+"a"+(mr-1)+",";
                windex+=1;
//                val +=1;               
            }
            if (cdata[mc].question_number!==cdata[mca].question_number){
                mr =0;
            }
        }
        document.getElementById("currquestion").innerHTML = ",q0";
//        localStorage.clear('data');
    }
    ////////////////////////////////////
    ////////////////////////////////////
    ////////////////////////////////////
    //https://stackoverflow.com/questions/33785313/javascript-loading-multiple-functions-onload
    window.addEventListener("load", myInit, true); function myInit(){
        getdata();
        getexp();
        getopts();
        copsorder();
        subbed();
        timeboxes();
        corrincorr(0);
    }
    function copsorder(){
    let text = document.getElementById("cslice").innerHTML;
    text = text.substring(0,text.length-1);
//                 "1,1,1,1,1,2,2,2,9,9,9,10,10,10,10,"
//    let result = "a,a,a,a,a,b,b,b,a,a,a,b,b,b,b,a,b,b,b";
    const myArray = text.split(",");
    var r = 0;
    var k = r+1;
    var m=1;
    var asbs = [];
    var useres = [];
    var indexletter = "a";
    for (var x=0; x<(myArray.length); x++){
        if (myArray[r]===myArray[k]){
            asbs.push(indexletter);
            useres.push(m);
            r+=1;
            k+=1;
        }
        else if (myArray[r]!==myArray[k]){
            asbs.push(indexletter);
            useres.push(m);
            r+=1;
            k+=1;
            m+=1;
            if (indexletter === "a"){
                    indexletter="b";
            } else {
                    indexletter = "a";
            }
        } 
    }
//    console.log(asbs);
//    console.log(useres);
    document.getElementById("cslice").innerHTML = useres;
}
function subbed(){
    var subdata = combdata[3];
    var sublen = subdata.length;
    var burnlen = document.getElementsByName("burn");
    var inputs=document.getElementById("onepick");
        for (var c=0; c<subdata.length; c++) {
            var subslice = subdata[c];
            document.getElementById("subqs").innerHTML += "s"+c+"a"+subslice+",";
            document.getElementById("tempanswers").innerHTML += ",q"+c+"a"+subslice;
        }
        if (subdata[0]!=='9'){
            document.getElementById("fern"+subdata[0]).checked=true;
            inputs.disabled=true;
        }
        else {
            for (var v =0; v<burnlen.length; v++){
            inputs.disabled=true;
            document.getElementById("fern"+v).checked=false;
            } 
        }
        document.getElementById("explanation0").style.display = 'block';
}
    function timeboxes(){
        var timedata = combdata[4];
        var timelen = timedata.length;
        for (var g=0; g<timedata.length; g++){
            document.getElementById("timebox").innerHTML += "<p id=\'timer"+g+"\' style=\'display\:none\'>0"+"</p>";
//            var newtime = new Date(timedata[g] * 1000).toISOString().substr(11, 8);
            document.getElementById("timer"+g).innerHTML += timedata[g]; 
        }
        timer();
    }
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
//https://stackoverflow.com/questions/15097315/change-onclick-attribute-with-javascript

    function toggle(id) {
//        var strid = id;
//        var result = strid.substring(8, );
//        var parsed = parseInt(result);
        var arrayline = document.getElementById("answersread").innerHTML;
        var cslices = document.getElementById("cslice").innerHTML;
        var cslicearr = cslices.split(",");
        var cslicelen = document.getElementById("sideLine").rows.length;
//        https://stackoverflow.com/questions/11742946/get-the-number-of-rows-in-a-html-table
//        var cslicelen = parseInt(cslicearr[cslicearr.length-2]);
        if (arrayline !== null) {
            if (arrayline.match("e"+id+",")!==null){
              document.getElementById("explanation"+id).style.display = 'block';
              if (document.getElementById("expimgb"+id).src!==window.location.href){
                  document.getElementById("home"+id).style.display="block";
              }
          } 
        }
        for (var i=0; i<cslicelen; i++){
            if ((""+i)===(""+id)) {
                document.getElementById("question"+i).style.display = 'block';
                document.getElementById("subbutton"+i).style.display = 'block';
                document.getElementById("explanation"+i).style.display = 'block';
            } else {
                document.getElementById("question"+i).style.display = 'none';
                document.getElementById("subbutton"+i).style.display = 'none';
                document.getElementById("explanation"+i).style.display = 'none';
            }
        }
        var unswers = document.getElementsByName("burn");
        document.getElementById("answersread").innerHTML += "e"+id + ",";
        var lice = document.getElementById("cslice").innerHTML;
        var licearr = lice.split(",");
        var licelen = parseInt(licearr[licearr.length-2]);
//        var cslicelen = document.getElementById("sideLine").rows.length;
        for (var ib=0; ib<licelen; ib++){
            if (("explanation"+ib)===("explanation"+id)) {
                document.getElementById("explanation"+ib).style.display = 'block';
                if (document.getElementById("expimgb"+ib).src!==window.location.href){
                  document.getElementById("home"+ib).style.display="block";
              }
            } else {
                document.getElementById("explanation"+ib).style.display = 'none';
                document.getElementById("home"+ib).style.display="none";
            }
        }
        for(var u=0;u<unswers.length;u++){
            if (unswers[u].checked === true) {
                document.getElementById("userquestions").innerHTML += "q" + id + ",";
                document.getElementById("useranswers").innerHTML += "a" + u +",";
//                document.getElementById("fern0").checked==true;
            } 
        }
    }
        
    function loadoptions(oid) {
        var ostrid = oid;
        var tele = document.getElementsByName("burn");
        var qnos = document.getElementById("cslice").innerHTML;
        var ctext = document.getElementById("cops").innerHTML;
        var clist = document.getElementById("corrects").innerHTML;
        var keylist = document.getElementById("answerkey").innerHTML;
        var rangeo = qnos.split(",");
        var rangee = ctext.split(",");
        var rangec = clist.split(",");
        var y = 0;
        var r = 0;
        for(var u=0;u<tele.length;u++){
                document.getElementById("fernsub"+y).innerHTML = '';
                document.getElementById("fern"+y).style.display = 'none';
                document.getElementById("fernsub"+y).style.display = 'none';
                y+=1;
            }
        for (var ul=0; ul<rangeo.length; ul++) {
            if (rangeo[ul] === oid) {
                document.getElementById("fernsub"+r).innerHTML = rangee[ul];
                document.getElementById("fern"+r).style.display = 'table-row';
                document.getElementById("fernsub"+r).style.display = 'inline';
                r +=1;
                }
            }
        var images = document.getElementsByName("questionimg");
        for (var gh=0; gh<images.length; gh++){
            document.getElementById("queimg"+gh).style.display = 'none';
            }
        var intoiddown = parseInt(oid)-1;
        if (document.getElementById("queimg"+intoiddown).src!==window.location.href){
            document.getElementById("queimg"+intoiddown).style.display = 'block';
            }
        }

    function qttempt(qno) {
        document.getElementById("tempquestions").innerHTML += ",q" +qno;
        document.getElementById("currquestion").innerHTML = ",q" +qno;
        document.getElementById("temptime").style.display = "none";
        document.getElementById("prevbutt").style.display="block";
        document.getElementById("nextbutt").style.display="block";
//        document.getElementById("temptime").innerHTML = 0;
//        elapsed = 0;
        var cello = document.getElementById('sideLine').getElementsByTagName('td');
        var lencello = cello.length;
        if (qno==(lencello-1)){
            document.getElementById("nextbutt").style.display="none";
        }
        if (qno==0){
            document.getElementById("prevbutt").style.display="none";
        }
    }
    function ansttempt(cno) {
        document.getElementById("tempanswers").innerHTML += document.getElementById("currquestion").innerHTML + "a" + cno;
        document.getElementById("lastanswer").innerHTML = "a" + cno;
        var quesource = document.getElementById("currquestion").innerHTML;
        var queno = quesource.substring(2,);
        var queint = parseInt(queno);
        document.getElementById("queb"+queno).innerHTML="Q"+(queint+1);
    }
    var dict = [];
    var queaudit = [];

    function subblock(sno) {
//        alert("subblock" + sno);
        var checksub = document.getElementById("subqs").innerHTML;
        var inputs=document.getElementById("onepick");
        var burnlen = document.getElementsByName("burn");
        var snostr = sno+"";
        var tempanswers= document.getElementById("tempanswers").innerHTML;
        var snolen = snostr.length;
        var chindex = tempanswers.lastIndexOf(",q"+sno+"a");
        var checkans = tempanswers.substring((chindex+snolen+3),(chindex+snolen+4));
        var y=0;
        var testq = (document.getElementById("subqs").innerHTML).match("s"+sno+"a");
        if (testq!==null && chindex!==-1 && checkans!=9){
            inputs.disabled=true;
//            alert("subblock if");
//            if question not answered but yes submitted, tempanswer indexof = -1, subq = exists
            document.getElementById("queb"+sno).innerHTML="Q"+(sno+1);
            document.getElementById("fern"+checkans).checked=true;
        } 
        else {
            for (var v =0; v<burnlen.length; v++){
                inputs.disabled=true;
                document.getElementById("fern"+v).checked=false;
            } 
        }
    }
    function markcurrque(int){
        var currque = document.getElementById("currquestion").innerHTML;
        var currquenum = parseInt(currque.substring(2,));
        for (var x=0;x<questionids.length;x++){
            document.getElementById("queb"+x).style.color=null;
        }
        document.getElementById("queb"+int).style.color='white';
    }
    function onefunction(num){
            var numup = parseInt(num)+1;
            var numupstr = numup +"";
            var numint = parseInt(num);
            var numstr = num+"";
            toggle(numstr);
            loadoptions(numupstr);
            qttempt(numint);
            subblock(numint);
            corrincorr(num);
            timer();
            markcurrque(num);
            document.getElementById("score").style.display = "none";
            document.getElementById("percentscore").style.display = "none";
    }
    
    
    function scoretest(){
        var subbedques = document.getElementById("subqs").innerHTML;
        var sqarray = subbedques.split(",");
        var anskey = document.getElementById("answerkey").innerHTML;
        var indexques = anskey.lastIndexOf("s");
        var indexans = anskey.lastIndexOf("a");
        var noques = parseInt(anskey.substring(indexques+1,indexans));
        var count = 0;
        for (any in sqarray){
            if (anskey.match(sqarray[any])!==null && (sqarray[any]).length>0){
                count +=1;
            }
        }
        var totque = noques+1;
        document.getElementById("score").innerHTML = count+" of "+ totque+" \.";
        document.getElementById("score").style.display = "block";
        var countint=(count);
        var percorr = (Math.round(100*(countint/(noques+1))));
        var strscore = " "+percorr +"\% total";
        var currqueno = 0;
        var currcorrper = 0;
        document.getElementById("percentscore").innerHTML= strscore;
        if ((subbedques.match(/s/g) || []).length>0){
            currqueno = (subbedques.match(/s/g) || []).length;
            currcorrper = (Math.round(100*(countint/(currqueno))));
            document.getElementById("percentscore").innerHTML= " "+strscore +" "+currcorrper +"\% attempted";
        }
        document.getElementById("percentscore").style.display = "block";
    }

    function corrincorr(inp){
        var keytocheck = document.getElementById("answerkey").innerHTML;
        var subquest = document.getElementById("subqs").innerHTML;
        var inplen = (inp+"").length;
        var lastindkey = keytocheck.lastIndexOf("s"+inp+"a");
        var lastindq = subquest.lastIndexOf("s"+inp+"a");
        var keyval = keytocheck.substring(lastindkey+inplen+2,lastindkey+inplen+3);
        var tele = document.getElementsByName("burn");
        for (var gu=0;gu<tele.length;gu++){
                document.getElementById("fernsub"+gu).style.borderStyle = "none";
            }
        document.getElementById("fernsub"+keyval).style.borderStyle = "solid";
        var queval = subquest.substring(lastindq+inplen+2,lastindq+inplen+3);
        document.getElementById("leftblank").style.display="none";
        document.getElementById("correctbox").style.display="none";
        document.getElementById("incorrectbox").style.display="none";
        if (keyval===queval){
            document.getElementById("correctbox").style.display="block";
            document.getElementById("incorrectbox").style.display="none";
            document.getElementById("leftblank").style.display="none";
        } else if (subquest.match("s"+inp+"a")!==null && keyval!==queval && queval.match("9")==null){
            document.getElementById("incorrectbox").style.display="block";
            document.getElementById("correctbox").style.display="none";
            document.getElementById("leftblank").style.display="none";
        } else if (subquest.match("s"+inp+"a9")!==null){
            document.getElementById("leftblank").style.display="block";
            document.getElementById("correctbox").style.display="none";
            document.getElementById("incorrectbox").style.display="none";
        } 
    }
    
    function timer(){
        document.getElementById("temptime").style.display = "block";
        var tno = parseInt((document.getElementById("currquestion").innerHTML).substring(2,));
        var tempque = document.getElementById("subqs").innerHTML;
//        if (tempque.match("s"+tno+"a")===null){
//            var timorg = parseInt(document.getElementById("timer"+tno).innerHTML);
//            var neworg = timorg += 1;
//            document.getElementById("timer"+tno).innerHTML = neworg;
//            var newtime = new Date(neworg * 1000).toISOString().substr(11, 8);
//            document.getElementById("temptime").innerHTML = newtime;
//        } 
//        else {
        var timorg = parseInt(document.getElementById("timer"+tno).innerHTML);
        var newtime = new Date(timorg * 1000).toISOString().substr(11, 8);
        document.getElementById("temptime").innerHTML = newtime;
//        }
    }
    function nextquestion(){
        var cells = document.getElementById('sideLine').getElementsByTagName('td');
//        var elements = document.getElementById('sideLine').children;
        var tqueno = cells.length;
        var openque = parseInt((document.getElementById("currquestion").innerHTML).substring(2,));
        var nextque = openque+1;
        if ((nextque+1)==(tqueno)){
            document.getElementById("nextbutt").style.display="none";
            document.getElementById('queb'+nextque).click();
        } else {
            document.getElementById('queb'+nextque).click();
        }
    }
    function prevquestion(){
        var tdsoftable = document.getElementById('sideLine').getElementsByTagName('td');
//        var elements = document.getElementById('sideLine').children;
        var quecollen = tdsoftable.length;
        var tdstoint = parseInt((document.getElementById("currquestion").innerHTML).substring(2,));
        var tdsintdown = tdstoint-1;
//        if ((tdstoint)==1){
//            document.getElementById("prevbutt").style.display="none";
//            document.getElementById('queb'+tdsintdown).click();
//        }  
        document.getElementById('queb'+tdsintdown).click();
    }
    function timershow(){
        if (document.getElementById("temptime").style.display === "block"){
            document.getElementById("temptime").style.display = "none";
        } else {
            document.getElementById("temptime").style.display = "block";
        }
    }
    
    function submitform(){
        window.location.href = 'selectpastexam.php';
    }
    var fontsize = 16;
    function darkmode(){
//        document.getElementsByTagName("body")[0].style.backgroundColor="blue";
//Dr. Dimitru document.body https://stackoverflow.com/questions/11721501/changing-body-tag-style-through-javascript
        if (document.body.style.backgroundColor==="white" || document.body.style.backgroundColor===''){
            document.body.style.backgroundColor="black";
            document.getElementById("quebox").style.color="red";
            document.getElementById("optbox").style.color="red";
            document.getElementById("timebox").style.color="red";
            document.getElementById("temptime").style.color="blue";
            document.getElementById("expbox").style.color="red";
            document.getElementById("correctbox").style.color="red";
            document.getElementById("incorrectbox").style.color="red";
            document.getElementById("leftblank").style.color="red";
            document.getElementById("darkmode").style.background="#002855";
            document.getElementById("fontbig").style.background="#002855";
            document.getElementById("fontsmall").style.background="#002855";
            document.getElementById("endexam").style.background="#002855";
            document.getElementById("nextbutt").style.background="blue";
            document.getElementById("nextbutt").style.color="red";
            document.getElementById("nextbutt").style.border="none";
            document.getElementById("nextbutt").style.borderRadius="5px";
            document.getElementById("prevbutt").style.background="blue";
            document.getElementById("prevbutt").style.color="red";
            document.getElementById("prevbutt").style.border="none";
            document.getElementById("prevbutt").style.borderRadius="5px";
            for (var x=0; x<questionids.length; x++){
                document.getElementById("subton"+x).style.background="blue";
                document.getElementById("subton"+x).style.color="red";
                document.getElementById("subton"+x).style.border="none";
                document.getElementById("subton"+x).style.borderRadius="5px";
            }
        } else {
            document.body.style.backgroundColor="white";
            document.getElementById("quebox").style.color="black";
            document.getElementById("optbox").style.color="black";
            document.getElementById("timebox").style.color="black";
            document.getElementById("temptime").style.color="blue";
            document.getElementById("expbox").style.color="black";
            document.getElementById("correctbox").style.color="black";
            document.getElementById("incorrectbox").style.color="black";
            document.getElementById("leftblank").style.color="black";
            document.getElementById("darkmode").style.background="blue";
            document.getElementById("fontbig").style.background="blue";
            document.getElementById("fontsmall").style.background="blue";
            document.getElementById("endexam").style.background="blue";
            document.getElementById("nextbutt").style.background=null;
            document.getElementById("nextbutt").style.color=null;
            document.getElementById("nextbutt").style.border=null;
            document.getElementById("nextbutt").style.borderRadius=null;
            document.getElementById("prevbutt").style.background=null;
            document.getElementById("prevbutt").style.color=null;
            document.getElementById("prevbutt").style.border=null;
            document.getElementById("prevbutt").style.borderRadius=null;
            for (var x=0; x<questionids.length; x++){
                document.getElementById("subton"+x).style.background=null;
                document.getElementById("subton"+x).style.color=null;
                document.getElementById("subton"+x).style.border=null;
                document.getElementById("subton"+x).style.borderRadius=null;
            }
        }
        
    }
    
    function fontbig(){
        fontsize+=1;
        document.getElementById("quebox").style.fontSize=fontsize;
        document.getElementById("optbox").style.fontSize=fontsize;
        document.getElementById("timebox").style.fontSize=fontsize;
        document.getElementById("temptime").style.fontSize=fontsize;
        document.getElementById("expbox").style.fontSize=fontsize;
        document.getElementById("nextbutt").style.fontSize=fontsize;
        document.getElementById("prevbutt").style.fontSize=fontsize;
        document.getElementById("correctbox").style.fontSize=fontsize;
        for (var x=0; x<questionids.length; x++){
            document.getElementById("subton"+x).style.fontSize=fontsize;
        }
    }
    function fontsmall(){
        fontsize-=1;
        document.getElementById("quebox").style.fontSize=fontsize;
        document.getElementById("optbox").style.fontSize=fontsize;
        document.getElementById("timebox").style.fontSize=fontsize;
        document.getElementById("temptime").style.fontSize=fontsize;
        document.getElementById("expbox").style.fontSize=fontsize;
        document.getElementById("correctbox").style.fontSize=fontsize;
        document.getElementById("nextbutt").style.fontSize=null;
        document.getElementById("prevbutt").style.fontSize=null;
        for (var x=0; x<questionids.length; x++){
            document.getElementById("subton"+x).style.fontSize=null;
        }
    }
    function makeexam(){
        window.location.href = 'selectdata4.php';
    }
//    function submitform(){
//        //need to deal with 'ab' left blank answers
////        var usersubs = document.getElementById("subqs").innerHTML;
////        var userans = document.getElementById("tempanswers").innerHTML;
//        var corrans = document.getElementById("answerkey").innerHTML;
//        var qno = corrans;
//        var qid = 1;
//        var eno = 1;
//        var firstans = 0;
//        var lastans = 1;
//        var corrans = 1;
//        var secondstaken = 60;
//        var httpr = new XMLHttpRequest();
//        httpr.open("POST","datalog.php",true);
//        httpr.setRequestHeader("Content-type","application/x-www-form-urlencoded");
//        httpr.onreadystatechange=function(){
//            if(httpr.readyState==4 && httpr.status==200){
//                document.getElementById("response").innerHTML=httpr.responseText;
//            }
//        }
//        httpr.send("qno="+qno+"&qid="+qid+"&eno="+eno+"&firstans="+firstans+"&lastans="+lastans+"&corrans="+corrans+"&secondstaken="+secondstaken);
//
//        
////        question_number`, `question_id`, `exam_number`, `first_answer`, `last_answer`, `correct_answer`, `seconds_taken
//    }
//    window.onbeforeunload = function() {
//  return "Data will be lost if you leave the page, are you sure?";
//};
//     https://stackoverflow.com/questions/1322732/convert-seconds-to-hh-mm-ss-with-javascript
//https://stackoverflow.com/questions/3221161/how-to-pop-up-an-alert-box-when-the-browsers-refresh-button-is-clicked
// shorter functions: https://www.youtube.com/watch?v=TIuap8Aybq0
// multiple versions of Jquery javascript on same page https://www.tutorialspoint.com/How-to-use-multiple-versions-of-jQuery-on-the-same-page
//https://stackoverflow.com/questions/7196212/how-to-create-dictionary-and-add-key-value-pairs-dynamically

    
</script>
<style>
subbutton {
    background: #000000;
    display: none;  
}
fieldset{
    border: none;
}


#question0 {
    display: block;
/*    background-color: #ffcc00;*/
}
#question1, #question2{
    display: none;
}

#explanation0, #explanation1, #explanation2{
    display: none;
}

#subbutton0{
    display: block;
}
#subbutton1, #subbutton2, #subbutton3, #subbutton4, #subbutton5, #subbutton6, #subbutton7, #subbutton8{
    display: none;
}
#answersread{
    display: none;
}
#fern0, #fern1, #fern2, #fern3, #fern4, #fern5, #fern6, #fern7{
    display: none;
    /*background-color: #ffcc00;*/
}
#fernsub0, #fernsub1, #fernsub2, #fernsub3, #fernsub4, #fernsub5, #fernsub6, #fernsub7{
    display: none;
    /*background-color: yellow;*/
}

#cslice{
    display: none;
    background-color: #ffcc00;
}
#cops{
    display: none;
    background-color: #ffcc00;
}
#corrects{
    display:none;
}
#useranswers{
    display: none;
}
#userquestions{
    display: none;
}
#temp0{
    background-color: blue;
}
#currquestion{
    display:none;
}
#lastanswer{
    display:none;
}
#tempquestions{
    display:none;
}
#tempanswers{
    display:none;
}
#subqs{
    display:none;
}
#answerkey{
    display:none;
}
#score{
    display:none;
    width: 120px;
}
#percentscore{
    display:none;
    width: 250px;
}
#correctbox{
    display:none;
}
#incorrectbox{
    display:none;
}
#leftblank{
    display:none;
}

#row {
  display: inline-block;
  padding: 0px;
  width: 100%;
  position: relative;
}

.column1 {
  padding: 0px;
  float:left;
  width:65px;
}

.column2 {
  padding: 0px;
  float:left;
  width:700px;
  empty-cells: hide;
}

#sideLine {
  border-collapse: collapse;
  border-spacing: 0;
  width: 50px;
  border: 1px solid #ddd;
}

#table2 {
  border-collapse: collapse;
  border-spacing: 10px;
  padding:0px;
  width: 100%;
  /*border: 1px solid #ddd;*/
  float: left;
}

td {
  text-align: left;
  vertical-align: top;
  padding: 6px;
}
.quebox > td{
    border-color: transparent;
    border-top-style: hidden;
    border-right-style: hidden;
    border-left-style: hidden;
}
.optionrow > td{
    /*border-top-style: solid;*/
    /*border-top-width: 1px;*/
    /*border-top-color: #ddd;*/
}

#expbox {
  border-collapse: collapse;
  border-spacing: 10px;
  padding:0px;
  width: 100%;
  border: 0px solid #ddd;
  float: left;
}
.GeneratedTable tr:nth-child(even) {
  background-color: #002855;
}
.GeneratedTable tr:nth-child(odd) {
  background-color: #EAAA00;
  color:#9ABEAA;
}
#buffer{
    width:100%;
    height: 50px;
}
#headrow{
    width:95%;
    height: 40px;
    display: flex;
    align-items: center;
    justify-content: center;
    background-color: #002855;
}
.overlay { 
    position: relative; 
}

.overlay .top {
  position: absolute;
  top: 0;
  left: 0;
  z-index: 1;
}
imgbox {
  width:40vw;
  /*height:40vh;*/
  /*background:#ccc;*/
  display:table-cell;
  vertical-align:middle;
  text-align:center;
}
img {
  max-width:100%;
  height:auto;
  max-height:100%;
  }
/*li{
	list-style: none;
}*/

/*.GeneratedTable input[type="radio"] {
  opacity: 0;
  position: fixed;
  width: 10px;
}

.GeneratedTable input[type="radio"]:checked + label {
    background-color:#bfb;
    border-color: #4c4;
}
.GeneratedTable input[type="radio"]:focus + label {
    border: 2px dashed #444;
}*/
/*https://stackoverflow.com/questions/16242980/making-radio-buttons-look-like-buttons-instead*/
</style>
<?php
// Start the buffering //
ob_start();
?>
<html>
<head>
<div id="buffer">
    <div id="headrow">
        <p id="exambox"></p>
        <p id="systembox"></p>
        <p id="qidbox"></p>
        <button type="button" onClick="scoretest();" style="display:none">Score Test</button>
        <button type="button" onClick="timershow();" style="display:none">Show/Hide Time</button>
        <!--questionaudit();-->
        <p id="score"></p>
        <div id="percentscore" style="color:white">0</div><div id="totalquestionnumber"></div>
        <button type="button" onClick="makeexam();" style="color:white;padding:5px 15px;font-size:14px;background-color:blue;border:none;border-radius:5px;" id="darkmode">Make Exam</button>
        <button type="button" onClick="darkmode();" style="color:white;padding:5px 15px;font-size:14px;background-color:blue;border:none;border-radius:5px;" id="darkmode">Dark Mode</button>
        <button type="button" onClick="fontsmall();" style="color:white;padding:5px 15px;font-size:14px;background-color:blue;border:none;border-radius:5px;" id="fontsmall">Font (-)</button>
        <button type="button" onClick="fontbig();" style="color:white;padding:5px 15px;font-size:14px;background-color:blue;border:none;border-radius:5px;" id="fontbig">Font (+)</button>
        <div class="menu-member">
                        <button type="button" onClick="submitform();" style="color:white;padding:5px 15px;font-size:14px;background-color:blue;border:none;border-radius:5px;" id="endexam">End Exam</button>
                        <?php
                            if(isset($_SESSION["userid"])){
                        ?>
                            <a href="javascript:;" style="text-decoration:none;color:#ffffff">|&ensp; <?php echo $_SESSION["useruid"]; ?>&ensp;</a>
                            <a href="../quiz/loginstuff/includes/logout.inc.php" class="header-login-a" style="text-decoration:none;color:#EAAA00;">Log Out</a>
                        <?php
                            }
                            else
                            {
                        ?>
                    <a href="#">SIGN UP</a>
                    <a href="#" class="header-login-a">LOGIN</a>
                        <?php
                        }
                        ?>
        </div>
    </div>
</div>
</head>
<body>
    <div id='row'>
        <div class='column1'>
            <table class="GeneratedTable" id="sideLine">
                <tbody>
                </tbody>   
            </table>
        </div>
        <div class='column2'>
            <table id='table2'>
                <tr  class="quebox">
                    <td style="min-width:100px;">
                        <p id="quebox" valign="top"></p>
                        <!--<img style="background:url(https://external-content.duckduckgo.com/iu/?u=https%3A%2F%2Ftse1.mm.bing.net%2Fth%3Fid%3DOIP.3AxpcEHATTGImtRFSKuZQQHaFj%26pid%3DApi&f=1); background-size: 200px 200px; background-repeat: no-repeat;" src="https://external-content.duckduckgo.com/iu/?u=http%3A%2F%2Ftinyurl.com%2F3km2h7z&f=1&nofb=1" alt="Galactic cat" width="200" height="200" align="right">-->
                    </td>
                    <!--https://external-content.duckduckgo.com/iu/?u=https%3A%2F%2Ffreepngimg.com%2Fthumb%2Fcowboy_hat%2F5-2-cowboy-hat-download-png-thumb.png&f=1&nofb=1-->
                    <td>
                        <p id="imgbox" valign="top"></p>
<!--                        <div class="overlay">
                            https://stackoverflow.com/questions/1074914/html-image-over-image
                            <img style="background:url(https://external-content.duckduckgo.com/iu/?u=https%3A%2F%2Fmir-s3-cdn-cf.behance.net%2Fproject_modules%2Fdisp%2Fff226524870735.5633b706414d3.jpg&f=1&nofb=1); background-size: 200px 200px; background-repeat: no-repeat;" src="https://external-content.duckduckgo.com/iu/?u=https%3A%2F%2Ffreepngimg.com%2Fthumb%2Fcowboy_hat%2F5-2-cowboy-hat-download-png-thumb.png&f=1&nofb=1" alt="Galactic cat" width="200" height="200" align="right">
                            <img class="top" src="https://external-content.duckduckgo.com/iu/?u=https%3A%2F%2Fmir-s3-cdn-cf.behance.net%2Fproject_modules%2Fdisp%2Fff226524870735.5633b706414d3.jpg&f=1&nofb=1" alt="" style="z-index: 0; position: absolute" width="200" height="200" align="right">
                            <img class="bottom" src="https://external-content.duckduckgo.com/iu/?u=https%3A%2F%2Ffreepngimg.com%2Fthumb%2Fcowboy_hat%2F5-2-cowboy-hat-download-png-thumb.png&f=1&nofb=1" alt="" style="z-index: 0; position: absolute" width="200" height="200" align="right">
                        </div>-->
                    </td>
                    <td></td>
                </tr>
                </table>
            <table>
                <tr class="optionrow">
                    <td id="optbox">
                        <fieldset name="hiburn" id="onepick">
                            <input type="radio" id="fern0" name="burn" value="kern0" onClick="ansttempt(0);">
                            <label for="fern0" id="fernsub0"></label><br>
                            <input type="radio" id="fern1" name="burn" value="kern1" onClick="ansttempt(1);">
                            <label for="fern1" id="fernsub1"></label><br>
                            <input type="radio" id="fern2" name="burn" value="burn2" onClick="ansttempt(2);">
                            <label for="fern2" id="fernsub2"></label><br>
                            <input type="radio" id="fern3" name="burn" value="burn3" onClick="ansttempt(3);">
                            <label for="fern3" id="fernsub3"></label><br>
                            <input type="radio" id="fern4" name="burn" value="burn4" onClick="ansttempt(4);">
                            <label for="fern4" id="fernsub4"></label>
                            <input type="radio" id="fern5" name="burn" value="burn5" onClick="ansttempt(5);">
                            <label for="fern5" id="fernsub5"></label>
                            <input type="radio" id="fern6" name="burn" value="burn6" onClick="ansttempt(6);">
                            <label for="fern6" id="fernsub6"></label>
                            <input type="radio" id="fern7" name="burn" value="burn7" onClick="ansttempt(7);">
                            <label for="fern7" id="fernsub7"></label>
                        </fieldset>
                    </td>
                    <td></td>
                    <td></td>
                </tr>
            </table>
            <table>
                <tr>
                    <td id="subbox">
                    </td>
                    <td id="timebox">
                        <p>Time taken: <a href="#" style="text-decoration: none; width: 25px;" id="temptime"></a></p>
                        <p id="timer0" style="display:none">0</p>
                    </td>
                    <td> 
                        <button type="button" id="prevbutt" onClick="prevquestion();" style="display:none;">Previous</button>
                    </td>
                    <td>
                        <button type="button" id="nextbutt" onClick="nextquestion();">Next</button>
                    </td>
                    <td>
                        <p id="correctbox">Correct</p>
                        <p id="incorrectbox">Incorrect</p>
                        <p id="leftblank">Left Blank</p> 
                    </td>
                </tr>
            </table>
            <table><td id="expimage"></td></table>
            <p id="expbox"></p>
        </div>
    </div>
    <div id="answersread"></div>
    <p id="cslice"></p>
    <p id="cops"></p>
    <p id="corrects"></p>
    <p id="userquestions"></p>
    <p id="useranswers"></p>
    <p id="currquestion"></p>
    <p id="lastanswer"></p>
    <p id="tempquestions"></p>
    <p id="tempanswers"></p>
    <p id="subqs"></p>
    <p id="answerkey"></p>
    <p id="response"></p>
    <p id="examnumber"></p>
    <p id="lastexamnumber"></p>
    
    <!--<form method="POST" action="datalog.php">-->
        <!--<input type="text" name="customerName" placeholder="Enter customer name" required>-->

<!--        <table>
            <tr>
                <th>QNO</th>
                <th>QID</th>
                <th>ENO</th>
                <th>FirstAns</th>
                <th>LastAns</th>
                <th>CorrAns</th>
                <th>SecondsTaken</th>
            </tr>
            <tbody id="tbody"></tbody>
        </table>

        
        <div id="subbuttonhere"></div> 
    </form>
    <button type="button" id="addrow">Add Item</button>-->
<!--<input type="button" id="primaryButton" onclick="onefunction(1)" />-->
<!--<input type="button" id="secondaryButton" onclick="document.getElementById('queb1').click();nextquestion();" />-->    

</body>
</html>
<?php
// Start the buffering //
//ob_start();
?>
<?php
//Arasalan Tabassum https://stackoverflow.com/questions/1917576/how-do-i-pass-javascript-variables-to-php

//echo '1';
//Save PHP page as HTML https://stackoverflow.com/questions/3775281/save-current-page-as-html-to-server
// Get the content that is in the buffer and put it in your file //
//file_put_contents('emptyslider3.php', ob_get_contents());
//if(array_key_exists('test',$_POST)){
//                   testfun();
//                }
//function testfun(){
//    file_put_contents('emptyslider4.php', ob_get_contents());
//}              
?>