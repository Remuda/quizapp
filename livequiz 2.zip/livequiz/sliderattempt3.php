<!--<table>
    <tr>
    <th>Question Number</th>
    <th>Question Text</th>
    </tr>
 
    <tbody id="data"></tbody>
</table>-->

<script>
    var ajax = new XMLHttpRequest();
    ajax.open("GET", "data.php", true);
    ajax.send();
    ajax.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
        var data = JSON.parse(this.responseText);
//        console.log(data);
        var qcolumn = "";
        var questiono = "";
        var datalen = data.length;
        for (var a=0; a< data.length; a++){
            qcolumn += "<tr>";
                qcolumn += "<td>";
                qcolumn+="<a href=\'#\' id=\'queb"+a+"\' onClick=\'onefunction("+a+")\'>•Q"+(a+1);
                qcolumn+="</a>";
                qcolumn+="</td>";
            qcolumn += "</tr>";
            
            questiono += "<div id=\'question"+a+"\'>";
            questiono += "</div>";

//            html += "<tr>";
//                html += "<td>" + question_num + "</td>";
//                html += "<td>" + question_tx + "</td>";
//            html += "</tr>";
        }
        document.getElementById("sideLine").innerHTML += qcolumn;
        document.getElementById("quebox").innerHTML += questiono;
//        document.getElementById("data").innerHTML = html;
        for (var ab=0; ab<datalen; ab++){
            document.getElementById("question"+ab).innerHTML = data[ab].question_text;
            document.getElementById("question"+ab).style.display="none";
        }
        document.getElementById("question0").style.display="block";
        }
    };
    var ajax = new XMLHttpRequest();
    ajax.open("GET", "explanationdata.php", true);
    ajax.send();
    ajax.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
        var edata = JSON.parse(this.responseText);
//        console.log(edata);
        var subbo = "";
        var explano = "";
        var edatalen = edata.length;
        for (var b=0; b< edata.length; b++){
            
            subbo += "<div id=\'subbutton"+b+"\'>";
                subbo += "<button type=\'button\' id=\'subton"+b+"\' onClick=\'twofunction("+b+")\'>";
                subbo += "Submit";
                subbo += "</button>";
            subbo += "</div>";
                
                
            explano += "<div id=\'explanation"+b+"\'>";
            explano += "</div>";
            
            
        }
        document.getElementById("subbox").innerHTML += subbo;
        document.getElementById("expbox").innerHTML += explano;
        for (var bb=0; bb<edatalen; bb++){
            document.getElementById("explanation"+bb).innerHTML = edata[bb].explanation_text;
            document.getElementById("explanation"+bb).style.display="none";
            document.getElementById("subbutton"+bb).style.display="none";
        }
        document.getElementById("subbutton0").style.display="block";
        }
        
    };    
    
    
    
    
    
    var ajax = new XMLHttpRequest();
    ajax.open("GET", "optiondata.php", true);
    ajax.send();
    ajax.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
        var cdata = JSON.parse(this.responseText);
//        console.log(cdata);
//        var html = "";
        var clen = cdata.length;
        for (var c=0; c<cdata.length; c++) {
            var cslice = cdata[c].question_number;
            document.getElementById("cslice").innerHTML += cslice + ",";
            var cops = cdata[c].coption;
            document.getElementById("cops").innerHTML += cops + ",";
            var corrects = cdata[c].is_correct;
            document.getElementById("corrects").innerHTML += corrects + ",";
//            html += "<tr>";
//            html += "<td>" + cslice + "</td>";
//            html += "<td>" + cops + "</td>";
//            html += "</tr>";
//            document.getElementById("choicetext").innerHTML = html;
        }
        
        for (var c=0; c< cdata.length ; c++) {
            var k=0;
            if (cdata[k].question_number===cdata[c].question_number){
                document.getElementById("fernsub"+c).innerHTML=cdata[c].coption;
                document.getElementById("fern"+c).style.display = 'table-row';
                document.getElementById("fernsub"+c).style.display = 'inline';
                
//                if (cdata[c].is_correct==="1"){
//                    document.getElementById("answerkey").innerHTML += "s0,a"+c+",";
//                }
                k+=1;                
            } else {
                break;
            }
        }
        var mr=0
        for (var mc=0; mc<(clen-1) ; mc++) {
            var mca = mc+1;
            mr += 1;
            if (cdata[mc].is_correct==="1"){
                document.getElementById("answerkey").innerHTML += "s"+(parseInt(cdata[mc].question_number)-1)+"a"+(mr-1)+",";
//                val +=1;               
            }
            if (cdata[mc].question_number!==cdata[mca].question_number){
                mr =0;
            }
        }

        }
        document.getElementById("currquestion").innerHTML = ",q0";
    };
    
    
    function toggle(id) {
//        var strid = id;
//        var result = strid.substring(8, );
//        var parsed = parseInt(result);
        var arrayline = document.getElementById("answersread").innerHTML;
        var cslices = document.getElementById("cslice").innerHTML;
        var cslicearr = cslices.split(",");
        var cslicelen = parseInt(cslicearr[cslicearr.length-2]);
        if (arrayline !== null) {
            if (arrayline.match("e"+id+",")!==null){
              document.getElementById("explanation"+id).style.display = 'block';
          }
        }
        for (var i=0; i<cslicelen; i++){
            if ((""+i)===(""+id)) {
                document.getElementById("question"+i).style.display = 'block';
                document.getElementById("subbutton"+i).style.display = 'block';
            } else {
                document.getElementById("question"+i).style.display = 'none';
                document.getElementById("subbutton"+i).style.display = 'none';
                document.getElementById("explanation"+i).style.display = 'none';
            }
        }
    }
    
    function etoggle(eid) {
//        var estrid = eid;
//        var eresult = estrid.substring(11, );
//        var eparsed = parseInt(eresult);
        var unswers = document.getElementsByName("burn");
        document.getElementById("answersread").innerHTML += "e"+eid + ",";
        var lice = document.getElementById("cslice").innerHTML;
        var licearr = lice.split(",");
        var licelen = parseInt(licearr[licearr.length-2]);
        for (var ib=0; ib<licelen; ib++){
            if (("explanation"+ib)===("explanation"+eid)) {
                document.getElementById("explanation"+ib).style.display = 'block';
            } else {
                document.getElementById("explanation"+ib).style.display = 'none';
            }
        }
        for(var u=0;u<unswers.length;u++){
            if (unswers[u].checked === true) {
                document.getElementById("userquestions").innerHTML += "q" + eid + ",";
                document.getElementById("useranswers").innerHTML += "a" + u +",";
//                document.getElementById("fern0").checked==true;
            } 
        }
    }
    
        
    function loadoptions(oid) {
        var ostrid = oid;
        var tele = document.getElementsByName("burn");
        var qnos = document.getElementById("cslice").innerHTML;
        var ctext = document.getElementById("cops").innerHTML;
        var clist = document.getElementById("corrects").innerHTML;
        var keylist = document.getElementById("answerkey").innerHTML;
        var rangeo = qnos.split(",");
        var rangee = ctext.split(",");
        var rangec = clist.split(",");
        var y = 0;
        var r = 0;
        for(var u=0;u<tele.length;u++){
                document.getElementById("fernsub"+y).innerHTML = '';
                document.getElementById("fern"+y).style.display = 'none';
                document.getElementById("fernsub"+y).style.display = 'none';
                y+=1;
            }
        for (var ul=0; ul<rangeo.length; ul++) {
            if (rangeo[ul] === oid) {
                document.getElementById("fernsub"+r).innerHTML = rangee[ul];
                document.getElementById("fern"+r).style.display = 'table-row';
                document.getElementById("fernsub"+r).style.display = 'inline';
                r +=1;
                }
            }
        }

    function clearchecks(mow) {
    var checkcheck = document.getElementById("subqs").innerHTML;
    
    }
    function qttempt(qno) {
        document.getElementById("tempquestions").innerHTML += ",q" +qno;
        document.getElementById("currquestion").innerHTML = ",q" +qno;
        document.getElementById("temptime").style.display = "none";
        document.getElementById("prevbutt").style.display="block";
        document.getElementById("nextbutt").style.display="block";
        document.getElementById("temptime").innerHTML = 0;
        elapsed = 0;
        var cello = document.getElementById('sideLine').getElementsByTagName('td');
        var lencello = cello.length;
        if (qno==(lencello-1)){
            document.getElementById("nextbutt").style.display="none";
        }
        if (qno==0){
            document.getElementById("prevbutt").style.display="none";
        }
    }
    function ansttempt(cno) {
        document.getElementById("tempanswers").innerHTML += document.getElementById("currquestion").innerHTML + "a" + cno;
        document.getElementById("lastanswer").innerHTML = "a" + cno;
        var quesource = document.getElementById("currquestion").innerHTML;
        var queno = quesource.substring(2,);
        var queint = parseInt(queno);
        document.getElementById("queb"+queno).innerHTML="Q"+(queint+1);
    }
    var dict = [];
    function sttempt(sni) {
        var snilen = (sni+"").length;
        var subarr = [];
        if ((document.getElementById("tempanswers").innerHTML).match(",q"+sni+"a")!==null){
            var snindex = (document.getElementById("tempanswers").innerHTML).lastIndexOf(",q"+sni+"a");
            var subqtext = (document.getElementById("tempanswers").innerHTML).substring((snindex+2),(snindex+snilen+4));
//            alert("subqtext "+subqtext);
            subarr = subqtext.split("a");
            document.getElementById("subqs").innerHTML += "s" + subqtext + ",";
        } else {
            document.getElementById("subqs").innerHTML += "s" + sni + "ab,";
            document.getElementById("lastanswer").innerHTML = "";
        }
//        document.getElementById("subton"+sni).disabled = true;
//        addItem(sni);
//        Adding stuff to form starts henceforth
        var firstindex = (document.getElementById("tempanswers").innerHTML).indexOf(",q"+sni+"a");
        var firsttext = (document.getElementById("tempanswers").innerHTML).substring((snindex+2),(snindex+snilen+4));
        var firstarr = [];
        firstarr = firsttext.split("a");
        const secondsans = document.getElementById("timer"+sni).innerHTML;
        var inputstr = sni+"";
        var inputlength = inputstr.length;
        var checkthiskey = document.getElementById("answerkey").innerHTML;
        var indexinkey = checkthiskey.lastIndexOf("s"+sni+"a");
        var ansval = checkthiskey.substring(indexinkey+inputlength+2,indexinkey+inputlength+3);
        var lastanssub = document.getElementById("subqs").innerHTML;
        var lsubindex = lastanssub.lastIndexOf("s"+sni+"a");
        var subval = lastanssub.substring(lsubindex+inputlength+2,lsubindex+inputlength+3);
//        document.getElementById("corrans"+sni).value = ansval;
//        if subarr[0] or firstarr[1] are undefined, replace with 9
        if (subarr[0]==null){ subarr[0] = 9;}
        if (firstarr[1]==null){ firstarr[1] = 9;}
        if (subval==="b"){ subval = 9;}
        dict.push(("qno"+sni),sni);
        //sni and subarr[0] are both question numbers
        dict.push(("qid"+sni),subarr[0]);
        //exam no is 1 by default, need to get value from table
        dict.push(("eno"+sni),1);
        //firstarr[1] is tempanswers lastindex and subval is subqs value
        dict.push(("firstans"+sni),firstarr[1]);
        dict.push(("lastans"+sni),subval);
        //ansval is the answerkey value or correct answer
        dict.push(("corrans"+sni),ansval);
        //secondsans is seconds taken
        dict.push(("secondstaken"+sni),secondsans);
//        console.log(dict);
    }
    
    function subblock(sno) {
//        alert("subblock" + sno);
        var checksub = document.getElementById("subqs").innerHTML;
        var inputs=document.getElementById("onepick");
        var burnlen = document.getElementsByName("burn");
        var snostr = sno+"";
        var tempanswers= document.getElementById("tempanswers").innerHTML;
        var snolen = snostr.length;
        var chindex = tempanswers.lastIndexOf(",q"+sno+"a");
        var checkans = tempanswers.substring((chindex+snolen+3),(chindex+snolen+4));
        var y=0;
        var testq = (document.getElementById("subqs").innerHTML).match("s"+sno+"a");
        if (testq!==null && chindex!==-1){
            inputs.disabled=true;
//            alert("subblock if");
//            if question not answered but yes submitted, tempanswer indexof = -1, subq = exists
            document.getElementById("queb"+sno).innerHTML="Q"+(sno+1);
            document.getElementById("fern"+checkans).checked=true;
        } else if(testq!==null && chindex==-1){
            inputs.disabled=true;
            document.getElementById("queb"+sno).innerHTML="Q"+(sno+1);
        }
        else if (tempanswers.match(",q"+sno+"a")!==null && testq===null){
//            alert ("subblock elseif");
            document.getElementById("fern"+checkans).checked=true;
            inputs.disabled=false;
        }
        else {
            for (v =0; v<burnlen.length; v++){
            inputs.disabled=false;
            document.getElementById("fern"+y).checked=false;
            y+=1;
            } 
        }
    }
    function onefunction(num){
            var numup = parseInt(num)+1;
            var numupstr = numup +"";
            var numint = parseInt(num);
            var numstr = num+"";
            toggle(numstr);
            loadoptions(numupstr);
            qttempt(numint);
            subblock(numint);
            corrincorr(num);
            addtimer(num);
            document.getElementById("score").style.display = "none";
            document.getElementById("percentscore").style.display = "none";
    }
    
    function twofunction(bub){
        var bubstr = bub+"";
        var bubint = parseInt(bub);
        etoggle(bubstr);
        sttempt(bubint);
        subblock(bubint);
        corrincorr(bub);
    }
    
    function scoretest(){
        var subbedques = document.getElementById("subqs").innerHTML;
        var sqarray = subbedques.split(",");
        var anskey = document.getElementById("answerkey").innerHTML;
        var indexques = anskey.lastIndexOf("s");
        var indexans = anskey.lastIndexOf("a");
        var noques = parseInt(anskey.substring(indexques+1,indexans));
        var count = 0;
        for (any in sqarray){
            if (anskey.match(sqarray[any])!==null && (sqarray[any]).length>0){
                count +=1;
            }
        }
        var totque = noques+1;
        document.getElementById("score").innerHTML = count+" of "+ totque+" \.";
        document.getElementById("score").style.display = "block";
        var countint=(count);
        var percorr = (Math.round(100*(countint/(noques+1))));
        var strscore = " "+percorr +"\% total";
        var currqueno = 0;
        var currcorrper = 0;
        document.getElementById("percentscore").innerHTML= strscore;
        if ((subbedques.match(/s/g) || []).length>0){
            currqueno = (subbedques.match(/s/g) || []).length;
            currcorrper = (Math.round(100*(countint/(currqueno))));
            document.getElementById("percentscore").innerHTML= " "+strscore +" "+currcorrper +"\% attempted";
        }
        document.getElementById("percentscore").style.display = "block";
    }
    
    function corrincorr(inp){
        var keytocheck = document.getElementById("answerkey").innerHTML;
        var subquest = document.getElementById("subqs").innerHTML;
        var inplen = (inp+"").length;
        var lastindkey = keytocheck.lastIndexOf("s"+inp+"a");
        var lastindq = subquest.lastIndexOf("s"+inp+"a");
        var keyval = keytocheck.substring(lastindkey+inplen+2,lastindkey+inplen+3);
        var queval = subquest.substring(lastindq+inplen+2,lastindq+inplen+3);
        document.getElementById("leftblank").style.display="none";
        document.getElementById("correctbox").style.display="none";
        document.getElementById("incorrectbox").style.display="none";
        if (keyval===queval){
            document.getElementById("correctbox").style.display="block";
            document.getElementById("incorrectbox").style.display="none";
            document.getElementById("leftblank").style.display="none";
        } else if (subquest.match("s"+inp+"a")!==null && keyval!==queval && queval.match("b")==null){
            document.getElementById("incorrectbox").style.display="block";
            document.getElementById("correctbox").style.display="none";
            document.getElementById("leftblank").style.display="none";
        } else if (subquest.match("s"+inp+"ab")!==null){
            document.getElementById("leftblank").style.display="block";
            document.getElementById("correctbox").style.display="none";
            document.getElementById("incorrectbox").style.display="none";
        } 
    }
    function addtimer(qno){
        if ((document.getElementById("timer"+qno))==null){
            document.getElementById("timebox").innerHTML += "<p id=\'timer"+qno+"\' style=\'display\:none\'>0"+"</p>";
        }
    }
    var elapsed = 0;
    setInterval(timer, 1000);
    
    function timer(){
        document.getElementById("temptime").style.display = "block";
        var tno = parseInt((document.getElementById("currquestion").innerHTML).substring(2,));
        var tempque = document.getElementById("subqs").innerHTML;
        if (tempque.match("s"+tno+"a")===null){
            elapsed +=1
            var timorg = parseInt(document.getElementById("timer"+tno).innerHTML);
            var neworg = timorg += 1;
            document.getElementById("timer"+tno).innerHTML = neworg;
            var newtime = new Date(neworg * 1000).toISOString().substr(11, 8);
            document.getElementById("temptime").innerHTML = newtime;
        } else {
            elapsed += 0;
            var timorg = parseInt(document.getElementById("timer"+tno).innerHTML);
            var newtime = new Date(timorg * 1000).toISOString().substr(11, 8);
            document.getElementById("temptime").innerHTML = newtime;
        }
    }
    function nextquestion(){
        var cells = document.getElementById('sideLine').getElementsByTagName('td');
//        var elements = document.getElementById('sideLine').children;
        var tqueno = cells.length;
        var openque = parseInt((document.getElementById("currquestion").innerHTML).substring(2,));
        var nextque = openque+1;
        if ((nextque+1)==(tqueno)){
            document.getElementById("nextbutt").style.display="none";
            document.getElementById('queb'+nextque).click();
        } else {
            document.getElementById('queb'+nextque).click();
        }
    }
    function prevquestion(){
        var tdsoftable = document.getElementById('sideLine').getElementsByTagName('td');
//        var elements = document.getElementById('sideLine').children;
        var quecollen = tdsoftable.length;
        var tdstoint = parseInt((document.getElementById("currquestion").innerHTML).substring(2,));
        var tdsintdown = tdstoint-1;
//        if ((tdstoint)==1){
//            document.getElementById("prevbutt").style.display="none";
//            document.getElementById('queb'+tdsintdown).click();
//        }  
        document.getElementById('queb'+tdsintdown).click();
    }
//    function timershow(){
//        if (document.getElementById("temptime").style.display === "block"){
//            document.getElementById("temptime").style.display = "none";
//        } else {
//            document.getElementById("temptime").style.display = "block";
//        }
//    }
    function submitform(){
//        document.getElementById("subbuttonhere").innerHTML = "<input type=\'submit\' name=\'submit\' id=\'examsubmit\' value=\'Add Invoic\'>";      
//        document.getElementById("examsubmit").click();
          const jsondict = JSON.stringify(dict);
//          console.log(jsondict);
          const xhr = new XMLHttpRequest();
          xhr.open("POST","datalog.php");
          xhr.setRequestHeader("Content-Type","application/json");
          xhr.send(jsondict);
    }
    
//    var qno = 0;
    function addItem(val){
        var html = "<tr>";
            html += "<td><input name='qno[]' id='qno"+val+"'></td>"; 
            html += "<td><input name='qid[]'id='qid"+val+"'></td>";
            html += "<td><input name='eno[]' id='eno"+val+"'></td>";
            html += "<td><input name='firstans[]' id='firstans"+val+"'></td>";
            html += "<td><input name='lastans[]' id='lastans"+val+"'></td>";
            html += "<td><input name='corrans[]' id='corrans"+val+"'></td>";
            html += "<td><input name='secondstaken[]' id='secondstaken"+val+"'></td>";
        html += "</tr>";
        document.getElementById("tbody").insertRow().innerHTML = html;
//      qno ++;
    }   
    
//    function submitform(){
//        //need to deal with 'ab' left blank answers
////        var usersubs = document.getElementById("subqs").innerHTML;
////        var userans = document.getElementById("tempanswers").innerHTML;
//        var corrans = document.getElementById("answerkey").innerHTML;
//        var qno = corrans;
//        var qid = 1;
//        var eno = 1;
//        var firstans = 0;
//        var lastans = 1;
//        var corrans = 1;
//        var secondstaken = 60;
//        var httpr = new XMLHttpRequest();
//        httpr.open("POST","datalog.php",true);
//        httpr.setRequestHeader("Content-type","application/x-www-form-urlencoded");
//        httpr.onreadystatechange=function(){
//            if(httpr.readyState==4 && httpr.status==200){
//                document.getElementById("response").innerHTML=httpr.responseText;
//            }
//        }
//        httpr.send("qno="+qno+"&qid="+qid+"&eno="+eno+"&firstans="+firstans+"&lastans="+lastans+"&corrans="+corrans+"&secondstaken="+secondstaken);
//
//        
////        question_number`, `question_id`, `exam_number`, `first_answer`, `last_answer`, `correct_answer`, `seconds_taken
//    }
//    window.onbeforeunload = function() {
//  return "Data will be lost if you leave the page, are you sure?";
//};
//     https://stackoverflow.com/questions/1322732/convert-seconds-to-hh-mm-ss-with-javascript
//https://stackoverflow.com/questions/3221161/how-to-pop-up-an-alert-box-when-the-browsers-refresh-button-is-clicked
// shorter functions: https://www.youtube.com/watch?v=TIuap8Aybq0
// multiple versions of Jquery javascript on same page https://www.tutorialspoint.com/How-to-use-multiple-versions-of-jQuery-on-the-same-page
//https://stackoverflow.com/questions/7196212/how-to-create-dictionary-and-add-key-value-pairs-dynamically
</script>
<html>
<head>
<style>
subbutton {
    background: #000000;
    display: none;  
}
fieldset{
    border: none;
}


#question0 {
    display: block;
/*    background-color: #ffcc00;*/
}
#question1, #question2{
    display: none;
}

#explanation0, #explanation1, #explanation2{
    display: none;
}

#subbutton0{
    display: block;
}
#subbutton1, #subbutton2, #subbutton3, #subbutton4, #subbutton5, #subbutton6, #subbutton7, #subbutton8{
    display: none;
}
#answersread{
    display: none;
}
#fern0, #fern1, #fern2, #fern3, #fern4, #fern5, #fern6, #fern7{
    display: none;
    /*background-color: #ffcc00;*/
}
#fernsub0, #fernsub1, #fernsub2, #fernsub3, #fernsub4, #fernsub5, #fernsub6, #fernsub7{
    display: none;
    /*background-color: yellow;*/
}

#cslice{
    display: none;
    background-color: #ffcc00;
}
#cops{
    display: none;
    background-color: #ffcc00;
}
#corrects{
    display:none;
}
#useranswers{
    display: none;
}
#userquestions{
    display: none;
}
#temp0{
    background-color: blue;
}
#currquestion{
    display:none;
}
#lastanswer{
    display:none;
}
#tempquestions{
    display:none;
}
#tempanswers{
    display:none;
}
#subqs{
    display:none;
}
#answerkey{
    display:none;
}
#score{
    display:none;
    width: 120px;
}
#percentscore{
    display:none;
    width: 250px;
}
#correctbox{
    display:none;
}
#incorrectbox{
    display:none;
}
#leftblank{
    display:none;
}

#row {
  display: inline-block;
  padding: 0px;
  width: 100%;
  position: relative;
}

.column1 {
  padding: 0px;
  float:left;
  width:65px;
}

.column2 {
  padding: 0px;
  float:left;
  width:700px;
  empty-cells: hide;
}

#sideLine {
  border-collapse: collapse;
  border-spacing: 0;
  width: 50px;
  border: 1px solid #ddd;
}

#table2 {
  border-collapse: collapse;
  border-spacing: 10px;
  padding:0px;
  width: 100%;
  border: 1px solid #ddd;
  float: left;
}

td {
  text-align: left;
  vertical-align: top;
  padding: 6px;
}
.quebox > td{
    border-color: transparent;
    border-top-style: hidden;
    border-right-style: hidden;
    border-left-style: hidden;
}
.optionrow > td{
    border-top-style: solid;
    border-top-width: 1px;
    border-top-color: #ddd;
}

#expbox {
  border-collapse: collapse;
  border-spacing: 10px;
  padding:0px;
  width: 100%;
  border: 0px solid #ddd;
  float: left;
}
tr:nth-child(even) {
  background-color: #f2f2f2;
}
#buffer{
    width:100%;
    height: 50px;
}
#headrow{
    width:95%;
    height: 40px;
    display: flex;
    align-items: center;
    justify-content: center;
    background-color: #f2f2f2;
}
.overlay { 
    position: relative; 
}

.overlay .top {
  position: absolute;
  top: 0;
  left: 0;
  z-index: 1;
}

/*li{
	list-style: none;
}*/

/*.GeneratedTable input[type="radio"] {
  opacity: 0;
  position: fixed;
  width: 10px;
}

.GeneratedTable input[type="radio"]:checked + label {
    background-color:#bfb;
    border-color: #4c4;
}
.GeneratedTable input[type="radio"]:focus + label {
    border: 2px dashed #444;
}*/
/*https://stackoverflow.com/questions/16242980/making-radio-buttons-look-like-buttons-instead*/
</style>
<div id="buffer">
    <div id="headrow">
        <button type="button" onClick="scoretest();">Score Test</button>
        <button type="button" onClick="timershow();">Show/Hide Time</button>
        <button type="button" onClick="submitform();">End Exam</button>
        <p id="score"></p>
        <p id="percentscore"></p>
    </div>
</div>
</head>
<body>
    <div id='row'>
        <div class='column1'>
            <table class="GeneratedTable" id="sideLine">
                <tbody>
                </tbody>   
            </table>
        </div>
        <div class='column2'>
            <table id='table2'>
                <tr  class="quebox">
                    <td>
                        <p id="quebox" valign="top"></p>
                        <!--<img style="background:url(https://external-content.duckduckgo.com/iu/?u=https%3A%2F%2Ftse1.mm.bing.net%2Fth%3Fid%3DOIP.3AxpcEHATTGImtRFSKuZQQHaFj%26pid%3DApi&f=1); background-size: 200px 200px; background-repeat: no-repeat;" src="https://external-content.duckduckgo.com/iu/?u=http%3A%2F%2Ftinyurl.com%2F3km2h7z&f=1&nofb=1" alt="Galactic cat" width="200" height="200" align="right">-->
                    </td>
                    <!--https://external-content.duckduckgo.com/iu/?u=https%3A%2F%2Ffreepngimg.com%2Fthumb%2Fcowboy_hat%2F5-2-cowboy-hat-download-png-thumb.png&f=1&nofb=1-->
                    <td>
<!--                        <div class="overlay">
                            https://stackoverflow.com/questions/1074914/html-image-over-image
                            <img style="background:url(https://external-content.duckduckgo.com/iu/?u=https%3A%2F%2Fmir-s3-cdn-cf.behance.net%2Fproject_modules%2Fdisp%2Fff226524870735.5633b706414d3.jpg&f=1&nofb=1); background-size: 200px 200px; background-repeat: no-repeat;" src="https://external-content.duckduckgo.com/iu/?u=https%3A%2F%2Ffreepngimg.com%2Fthumb%2Fcowboy_hat%2F5-2-cowboy-hat-download-png-thumb.png&f=1&nofb=1" alt="Galactic cat" width="200" height="200" align="right">
                            <img class="top" src="https://external-content.duckduckgo.com/iu/?u=https%3A%2F%2Fmir-s3-cdn-cf.behance.net%2Fproject_modules%2Fdisp%2Fff226524870735.5633b706414d3.jpg&f=1&nofb=1" alt="" style="z-index: 0; position: absolute" width="200" height="200" align="right">
                            <img class="bottom" src="https://external-content.duckduckgo.com/iu/?u=https%3A%2F%2Ffreepngimg.com%2Fthumb%2Fcowboy_hat%2F5-2-cowboy-hat-download-png-thumb.png&f=1&nofb=1" alt="" style="z-index: 0; position: absolute" width="200" height="200" align="right">
                        </div>-->
                    </td>
                    <td></td>
                </tr>
                <tr class="optionrow">
                    <td id="optbox">
                        <fieldset name="hiburn" id="onepick">
                            <input type="radio" id="fern0" name="burn" value="kern0" onClick="ansttempt(0);">
                            <label for="fern0" id="fernsub0"></label><br>
                            <input type="radio" id="fern1" name="burn" value="kern1" onClick="ansttempt(1);">
                            <label for="fern1" id="fernsub1"></label><br>
                            <input type="radio" id="fern2" name="burn" value="burn2" onClick="ansttempt(2);">
                            <label for="fern2" id="fernsub2"></label><br>
                            <input type="radio" id="fern3" name="burn" value="burn3" onClick="ansttempt(3);">
                            <label for="fern3" id="fernsub3"></label><br>
                            <input type="radio" id="fern4" name="burn" value="burn4" onClick="ansttempt(4);">
                            <label for="fern4" id="fernsub4"></label>
                            <input type="radio" id="fern5" name="burn" value="burn5" onClick="ansttempt(5);">
                            <label for="fern5" id="fernsub5"></label>
                            <input type="radio" id="fern6" name="burn" value="burn6" onClick="ansttempt(6);">
                            <label for="fern6" id="fernsub6"></label>
                            <input type="radio" id="fern7" name="burn" value="burn7" onClick="ansttempt(7);">
                            <label for="fern7" id="fernsub7"></label>
                        </fieldset>
                    </td>
                    <td></td>
                    <td></td>
                </tr>
                <tr>
                    <td id="subbox">
                    </td>
                    <td id="timebox">
                        <p>Time taken: <a href="#" style="text-decoration: none; width: 25px;" id="temptime"></a></p>
                        <p id="timer0" style="display:none">0</p>
                    </td>
                    <td> 
                        <button type="button" id="prevbutt" onClick="prevquestion();" style="display:none;">Previous</button>
                        <button type="button" id="nextbutt" onClick="nextquestion();">Next</button>
                        <p id="correctbox">Correct</p>
                        <p id="incorrectbox">Incorrect</p>
                        <p id="leftblank">Left Blank</p> 
                    </td>
                </tr>
            </table>
            <p id="expbox"></p>
        </div>
    </div>
    <div id="answersread"></div>
    <p id="cslice"></p>
    <p id="cops"></p>
    <p id="corrects"></p>
    <p id="userquestions"></p>
    <p id="useranswers"></p>
    <p id="currquestion"></p>
    <p id="lastanswer"></p>
    <p id="tempquestions"></p>
    <p id="tempanswers"></p>
    <p id="subqs"></p>
    <p id="answerkey"></p>
    <p id="response"></p>
    <p id="examnumber"></p>
    
    <!--<form method="POST" action="datalog.php">-->
        <!--<input type="text" name="customerName" placeholder="Enter customer name" required>-->

<!--        <table>
            <tr>
                <th>QNO</th>
                <th>QID</th>
                <th>ENO</th>
                <th>FirstAns</th>
                <th>LastAns</th>
                <th>CorrAns</th>
                <th>SecondsTaken</th>
            </tr>
            <tbody id="tbody"></tbody>
        </table>

        
        <div id="subbuttonhere"></div> 
    </form>
    <button type="button" id="addrow">Add Item</button>-->
<!--<input type="button" id="primaryButton" onclick="onefunction(1)" />-->
<!--<input type="button" id="secondaryButton" onclick="document.getElementById('queb1').click();nextquestion();" />-->    

</body>
</html>