<?php
session_start();
include "loginstuff/access.php";
access();
$userid = $_SESSION["userid"];
$dbhost = "localhost";
$dbuser = "root";
$dbpass = "";
$dbname = "demoquestions";

$connection = mysqli_connect($dbhost, $dbuser, $dbpass, $dbname);
//https://database.guide/how-to-return-the-number-of-rows-in-a-query-result-in-sql-server/
$result = mysqli_query($connection,"SELECT MAX(DISTINCT exam_number) AS 'exno' FROM `alluserattempts` WHERE `user_id` = '$userid';");    
$examno = array();
while ($row = mysqli_fetch_assoc($result))
{
    array_push($examno, $row['exno']);
}

echo json_encode($examno);
//echo json_encode($edata);
exit();

?>