<?php

$requestPayload = file_get_contents("php://input");
$object = json_decode($requestPayload);

$arr = $object[3];
$remove = rtrim($object[3], ", ");
//$newarr=explode(',',$remove);
$newarr=explode(',',$arr);
//echo json_encode($newarr);
//var_dump($object);
$dbhost = "localhost";
$dbuser = "root";
$dbpass = "";
$dbname = "demoquestions";
$startDT =$object[1];
$cars=$newarr;
$bars = 2;
$nums = 2;
$connection = mysqli_connect($dbhost, $dbuser, $dbpass, $dbname);
$email = $object[5];
//
$question_query = "SELECT  * 
FROM    `questions` 
WHERE   `exam` IN ('$startDT') 
AND     `system` IN (".implode(',',$newarr).")
LIMIT       ". $email . "";
$que_query_run = mysqli_query($connection,$question_query);
$data = array();
//
$counter = 0;
$exparr = array();
while ($row3 = mysqli_fetch_assoc($que_query_run))
{
    array_push($data, $row3);
    array_push($exparr,$data[$counter]['question_number']);
    $counter+=1;
}
//
$explanation_query = "SELECT  * 
FROM    `explanations` 
WHERE   `explanation_number` IN (".implode(',',$exparr).")";
$exp_query_run = mysqli_query($connection, $explanation_query);
$explanation = array();
while ($row4 = mysqli_fetch_assoc($exp_query_run))
{
    array_push($explanation, $row4);
}
//
$option_query = "SELECT  * 
FROM    `options` 
WHERE   `question_number` IN (".implode(',',$exparr).")";
$opt_query_run = mysqli_query($connection, $option_query);
$options = array();
while ($row5 = mysqli_fetch_assoc($opt_query_run))
{
    array_push($options, $row5);
}
$suparr = array();
array_push($suparr,$data);
array_push($suparr,$explanation);
array_push($suparr,$options);
////echo json_encode($data);
////echo json_encode($explanation);
echo json_encode($suparr);
//

?>
