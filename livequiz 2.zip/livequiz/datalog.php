<?php
session_start();
include "loginstuff/access.php";
access();
$userid = $_SESSION["userid"];
//Delete duplicates https://www.mysqltutorial.org/mysql-delete-duplicate-rows/
//Fix table key/autoincrement index https://stackoverflow.com/questions/740358/reorder-reset-auto-increment-primary-key
$requestPayload = file_get_contents("php://input");
$object = json_decode($requestPayload,true);
$conn = mysqli_connect("localhost","root","","demoquestions");
$maxlength = count($object)-4;
//echo json_encode($object);
//echo count($object);
//echo json_encode($object[1]);
//$examnumber = ($object[count($object)-3][0]);
$qidsforexam = $object[count($object)-3];
$qidstring = implode(',',$qidsforexam);
$predatetime = $object[count($object)-1];
$datetime = substr($predatetime,0,19);
//$qidstringfinal = str_replace(",","q",$qidstring);
//$myfile = fopen("newfile".$examnumber.".txt", "w") or die("Unable to open file!");
//fwrite($myfile, $qidstring);
//fclose($myfile);

//$sqlpastexam = "INSERT INTO pastexams (examnumber,qids,examdate) VALUES ('$examnumber','$qidstring','$datetime')";
//if (mysqli_query($conn,$sqlpastexam)){
//    echo "Data inserted successfully";
//} else {
//    echo "error creating record" .mysqli_error($conn);
//}
//
for ($i=0; $i<$maxlength; $i+=20){
    $iid=$i+1;
    $aid=$i+3;
    $bid=$i+5;
    $cid=$i+7;
    $did=$i+9;
    $eid=$i+11;
    $fid=$i+13;
    $gid=$i+15;
    $hid=$i+17;
    $jid=$i+19;

    $sqlall= "INSERT INTO alluserattempts(question_number, question_id, exam_number,first_answer, "
            . "last_answer, correct_answer, seconds_taken, exam, system, examdate, user_id, marked) "
            . "VALUES ('$object[$iid]','$object[$aid]','$object[$bid]','$object[$cid]',"
            . "'$object[$did]','$object[$eid]','$object[$fid]','$object[$gid]','$object[$hid]','$datetime',$userid,'$object[$jid]')";
    if(mysqli_query($conn,$sqlall)) {
        echo "Data inserted succesfully";
    } else {
        echo "error creating record" . mysqli_error($conn);
    }
    if ($object[$eid]=='0'){
        $sql= "INSERT INTO userattempts(question_number, question_id, exam_number,first_answer, "
                . "last_answer, correct_answer, seconds_taken, exam, system, user_id) "
                . "VALUES ('$object[$iid]','$object[$aid]','$object[$bid]','$object[$cid]',"
                . "'$object[$did]','$object[$eid]','$object[$fid]','$object[$gid]','$object[$hid]',$userid)";
        if(mysqli_query($conn,$sql)) {
            echo "Data inserted succesfully";
        } else {
            echo "error creating record" . mysqli_error($conn);
        }
    } elseif ($object[$eid]=='1'){
        $delquery = "DELETE FROM userattempts WHERE question_id=".$object[$aid]."";
        if(mysqli_query($conn,$delquery)) {
            echo "Data inserted succesfully";
        } else {
            echo "error creating record" . mysqli_error($conn);
        }
    } 
}
$remdupes = "DELETE t1 FROM userattempts t1 INNER JOIN userattempts t2 WHERE  t1.keyfortable < t2.keyfortable AND 
    t1.question_id = t2.question_id;";
if(mysqli_query($conn,$remdupes)) {
    echo "Data inserted succesfully";
} else {
    echo "error creating record" . mysqli_error($conn);
}

//
//
//
//
//
//
//
//
//    $sql = "INSERT INTO `userattempts`(`question_number`, `question_id`, `exam_number`, `first_answer`, `last_answer`, `correct_answer`, `seconds_taken`) 
//            VALUES ('$object[$iid]','$object[$aid]','$object[$bid]','$object[$cid]','$object[$did]','$object[$eid]','$object[$fid]')";
//    $sql="INSERT INTO `userattempts`(`question_number`, `question_id`, `exam_number`, `first_answer`, `last_answer`, `correct_answer`, `seconds_taken`) VALUES (LAST_INSERT_ID(),'$object[$i+3]','$object[$i+5]','$object[$i+7]','$object[$i+9]','$object[$i+11]','$object[$i+13]')";  
//https://www.tutorialrepublic.com/php-tutorial/php-mysql-insert-query.php
//session_start();
//$qno=$_POST['qno'];
//$qid=$_POST['qid'];
//$eno=$_POST['eno'];
//$firstans=$_POST['firstans'];
//$lastans=$_POST['lastans'];
//$corrans=$_POST['corrans'];
//$secondstaken=$_POST['secondstaken'];
//
//$conn = mysqli_connect("localhost","root","","demoquestions");
//if (isset($_POST["submit"])){
//    for ($a = 0; $a<3; $a++){
//        $sql="INSERT INTO `userattempts`(`question_number`, `question_id`, `exam_number`, `first_answer`, `last_answer`, `correct_answer`, `seconds_taken`) VALUES (LAST_INSERT_ID(),'$qid[$a]','$eno[$a]','$firstans[$a]','$lastans[$a]','$corrans[$a]','$secondstaken[$a]')";
//        mysqli_query($conn,$sql);
//        echo "<p>Submitted</p>";
//    }
//}
//    foreach($_POST as $i => $stuff) {
//        $sql="INSERT INTO `userattempts`(`question_number`, `question_id`, `exam_number`, `first_answer`, `last_answer`, `correct_answer`, `seconds_taken`) VALUES (LAST_INSERT_ID(),'$qid[$a]','$eno[$a]','$firstans[$a]','$lastans[$a]','$corrans[$a]','$secondstaken[$a]')";
//        mysqli_query($conn,$sql);
//        var_dump($i);
//        var_dump($stuff);
//        echo "<br>";
//        echo $corrans[0];
//}
//        $conn = mysqli_connect("localhost","root","","demoquestions");
//        for ($a = 0; $a < 3; $a++){
//            $sql = "INSERT INTO userattempts(question_number, question_id, exam_number, first_answer, last_answer, correct_answer, seconds_taken) VALUES (LAST_INSERT_ID(),'".$_POST["qid"][$a]."','".$_POST["eno"][$a]."','".$_POST["firstans"][$a]."','".$_POST["lastans"][$a]."','".$_POST["corrans"][$a]."','".$_POST["secondstaken"][$a]."')";
//            $sql="INSERT INTO `userattempts`(`question_number`, `question_id`, `exam_number`, `first_answer`, `last_answer`, `correct_answer`, `seconds_taken`) VALUES (LAST_INSERT_ID(),'$qid[$a]','$eno[$a]','$firstans[$a]','$lastans[$a]','$corrans[$a]','$secondstaken[$a]')";
//            mysqli_query($conn,$sql);
//            echo "<p>Submitted</p>";
//        }
//}

//$connection = mysqli_connect($dbhost, $dbuser, $dbpass, $dbname);
//if(isset($_POST['qid'])){
//$qno=$_POST['qno'];
//$qid=$_POST['qid'];
//$eno=$_POST['eno'];
//$firstans=$_POST['firstans'];
//$lastans=$_POST['lastans'];
//$corrans=$_POST['corrans'];
//$secondstaken=$_POST['secondstaken'];
//
//
//$qnumber = $_POST["qno"];
//$qnum_ar = explode(',',$qnumber);
//$maxl = count($qnum_ar);
//$maxlength = $maxl -1;
//for ($v = 0; $v < count($qnum_ar); $v++){
//    echo $qnum_ar[$v];
//}
//$sql="INSERT INTO `userattempts`(`question_number`, `question_id`, `exam_number`, `first_answer`, `last_answer`, `correct_answer`, `seconds_taken`) VALUES (LAST_INSERT_ID(),'$qid','$eno','$firstans','$lastans','$corrans','$secondstaken');";
//$result=mysqli_query($connection,$sql);

//if($result==true){
//    echo "<h3>Submitted</h3>";
//}
//   $fruits_ar = explode(‘, ‘, $fruits);     
        
        
//}
?>
