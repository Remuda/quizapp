<?php
    session_start();
    include "loginstuff/access.php";
    access();
    $userid = '';
    $date = new DateTime('+1');
    setcookie('session','abc', $date->getTimestamp());
    require 'functions.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Make Exam</title>
<header class="header-fixed">
	<div class="header-limiter">
		<h1><a href="#">ADAPTIVE<span>Test Bank</span></a></h1>
		<nav>
                    <a href="../quiz/loginstuff/windex.php" style="color:#EAAA00"><b>Home</b></a>
                    <a href="selectpastexam.php" style="color:#5383d3"><b>Past Exams</b></a>
                    <a href="selectdata4.php" style="color:#EAAA00" name="submit" onclick="window.location.href='http://localhost/quiz/selectdata4.php';"><b>Make Exam</b></a>
                    <a href="#" style="color:#5383d3"><b>|</b></a>
                        <?php
                            if(isset($_SESSION["userid"])){
                        ?>
                    <a href="#" style="color:#5383d3"><b><?php echo e($_SESSION["useruid"]); ?></b></a>
                    <a href="loginstuff/includes/logout.inc.php" class="header-login-a" style="color:#EAAA00"><b>Log Out</b></a>
                        <?php
                            }
                            else
                            {
                        ?>
                            <a href="#" style="color:#5383d3"><b>Sign Up</b></a>
                            <a href="#" class="header-login-a" style="color:#EAAA00"><b>Log In</b></a>
                        <?php
                        }
                        ?>
		</nav>
	</div>
</header>
<style>
.header-fixed {
	background-color:#292c2f;
	box-shadow:0 1px 1px #ccc;
	padding: 20px 40px;
	height: 80px;
	color: #A2AAAD;
	box-sizing: border-box;
	top:-100px;

	-webkit-transition:top 0.3s;
	transition:top 0.3s;
}

.header-fixed .header-limiter {
	max-width: 1200px;
	text-align: center;
	margin: 0 auto;
        color:#A2AAAD;
}

/*	The header placeholder. It is displayed when the header is fixed to the top of the
	browser window, in order to prevent the content of the page from jumping up. */

.header-fixed-placeholder{
	height: 80px;
	display: none;
}


.header-fixed .header-limiter h1 {
	float: left;
	font: normal 28px Cookie, Arial, Helvetica, sans-serif;
	line-height: 40px;
	margin: 0;
}

.header-fixed .header-limiter h1 span {
	color: #5383d3;
}

/* The navigation links */

.header-fixed .header-limiter a {
	color: #EAAA00;
	text-decoration: none;
}

.header-fixed .header-limiter nav {
	font:16px Arial, Helvetica, sans-serif;
	line-height: 40px;
	float: right;
}

.header-fixed .header-limiter nav a{
	display: inline-block;
	padding: 0 5px;
	text-decoration:none;
	color: #ffffff;
	opacity: 0.9;
}

.header-fixed .header-limiter nav a:hover{
	opacity: 1;
}

.header-fixed .header-limiter nav a.selected {
	color: #608bd2;
	pointer-events: none;
	opacity: 1;
}

/* Fixed version of the header */

body.fixed .header-fixed {
	padding: 10px 40px;
	height: 50px;
	position: fixed;
	width: 100%;
	top: 0;
	left: 0;
	z-index: 1;
}

body.fixed .header-fixed-placeholder {
	display: block;
}

body.fixed .header-fixed .header-limiter h1 {
	font-size: 24px;
	line-height: 30px;
}

body.fixed .header-fixed .header-limiter nav {
	line-height: 28px;
	font-size: 13px;
}


/* Making the header responsive */

@media all and (max-width: 600px) {

	.header-fixed {
		padding: 20px 0;
		height: 75px;
	}

	.header-fixed .header-limiter h1 {
		float: none;
		margin: -8px 0 10px;
		text-align: center;
		font-size: 24px;
		line-height: 1;
	}

	.header-fixed .header-limiter nav {
		line-height: 1;
		float:none;
	}

	.header-fixed .header-limiter nav a {
		font-size: 13px;
	}

	body.fixed .header-fixed {
		display: none;
	}

}

/*
	 We are clearing the body's margin and padding, so that the header fits properly.
	 We are also adding a height to demonstrate the scrolling behavior. You can remove
	 these styles.
 */

body {
	margin: 0;
	padding: 0;
	height: 1500px;
}    

        /* Customize the label (the container) */
.container {
  display: block;
  position: relative;
  padding-left: 35px;
  margin-bottom: 12px;
  cursor: pointer;
  font-size: 22px;
  -webkit-user-select: none;
  -moz-user-select: none;
  -ms-user-select: none;
  user-select: none;
}

/* Hide the browser's default checkbox */
.container input {
  position: absolute;
  opacity: 0;
  cursor: pointer;
  height: 0;
  width: 0;
}

/* Create a custom checkbox */
.checkmark {
  position: absolute;
  top: 0;
  left: 0;
  height: 25px;
  width: 25px;
  background-color: #eee;
}

/* On mouse-over, add a grey background color */
.container:hover input ~ .checkmark {
  background-color: #ccc;
}

/* When the checkbox is checked, add a blue background */
.container input:checked ~ .checkmark {
  background-color: #2196F3;
}

/* Create the checkmark/indicator (hidden when not checked) */
.checkmark:after {
  content: "";
  position: absolute;
  display: none;
}
.container:after{
  content: "";
  position: absolute;
  display: none;
  border-radius: 50%;
}
/* Show the checkmark when checked */
.container input:checked ~ .checkmark:after {
  display: block;
}

/* Style the checkmark/indicator */
.container .checkmark:after {
  left: 9px;
  top: 5px;
  width: 5px;
  height: 10px;
  border: solid white;
  border-width: 0 3px 3px 0;
  -webkit-transform: rotate(45deg);
  -ms-transform: rotate(45deg);
  transform: rotate(45deg);
}
/* Customize the label (the container) */
/*=================================================
=================================================*/
/* Customize the label (the container) */
.retainer {
  display: block;
  position: relative;
  padding-left: 35px;
  margin-bottom: 12px;
  cursor: pointer;
  font-size: 22px;
  -webkit-user-select: none;
  -moz-user-select: none;
  -ms-user-select: none;
  user-select: none;
}

/* Hide the browser's default radio button */
.retainer input {
  position: absolute;
  opacity: 0;
  cursor: pointer;
  height: 0;
  width: 0;
}

/* Create a custom radio button */
.radio {
  position: absolute;
  top: 0;
  left: 0;
  height: 25px;
  width: 25px;
  background-color: #eee;
  border-radius: 50%;
}

/* On mouse-over, add a grey background color */
.retainer:hover input ~ .radio {
  background-color: #ccc;
}

/* When the radio button is checked, add a blue background */
.retainer input:checked ~ .radio {
  background-color: #2196F3;
}

/* Create the indicator (the dot/circle - hidden when not checked) */
.radio:after {
  content: "";
  position: absolute;
  display: none;
}

/* Show the indicator (dot/circle) when checked */
.retainer input:checked ~ .checkmark:after {
  display: block;
}

/* Style the indicator (dot/circle) */
.retainer .radio:after {
  top: 9px;
  left: 9px;
  width: 8px;
  height: 8px;
  border-radius: 50%;
  background: white;
}
/*=================================================
=================================================*/
/* Customize the label (the container) */
/*=================================================
=================================================*/
/* Customize the label (the container) */
.retainerx {
  display: block;
  position: relative;
  padding-left: 35px;
  margin-bottom: 12px;
  /*cursor: pointer;*/
  font-size: 22px;
  color: grey;
  -webkit-user-select: none;
  -moz-user-select: none;
  -ms-user-select: none;
  user-select: none;
}

/* Hide the browser's default radio button */
/*https://jsfiddle.net/petrabarus/pPgS7/*/
.retainerx input {
  position: absolute;
  visibility:hidden;
  opacity: 0;
  cursor: pointer;
  height: 0;
  width: 0;
}

 /*Create a custom radio button*/ 
.radio {
  position: absolute;
  top: 0;
  left: 0;
  height: 25px;
  width: 25px;
  background-color: #eee;
  border-radius: 50%;
}

 /*On mouse-over, add a grey background color*/ 
.retainerx:hover input ~ .radio {
  background-color: #ccc;
  visibility:hidden;
}

 /*When the radio button is checked, add a blue background*/ 
.retainerx input:checked ~ .radio {
  background-color: #2196F3;
}

 /*Create the indicator (the dot/circle - hidden when not checked)*/ 
.radio:after {
  content: "";
  position: absolute;
  display: none;
}

 /*Show the indicator (dot/circle) when checked*/ 
.retainerx input:checked ~ .checkmark:after {
  display: block;
  visibility:hidden;
}

 /*Style the indicator (dot/circle)*/ 
.retainerx .radio:after {
  top: 9px;
  left: 9px;
  width: 8px;
  height: 8px;
  border-radius: 50%;
  background: white;
}
/*=================================================
=================================================*/
#heading{
    font-size: 22px;
}
#typeheading{
    font-size: 22px;
    float: right;
}
#generate{
    font-size: 22px;
}
.multiselect {
  width: 200px;
}

.selectBox {
  position: relative;
}

.selectBox select {
  width: 100%;
  font-weight: bold;
}

.overSelect {
  position: absolute;
  left: 0;
  right: 0;
  top: 0;
  bottom: 0;
}

#checkboxes0, #checkboxes1, #checkboxes2, #checkboxes3, #checkboxes4, #checkboxes5{
  display: none;
  border: 1px #dadada solid;
  font-size:20px;
}

#checkboxes0 label {
  display: block;
}

#checkboxes1 label {
  display: block;
}
#checkboxes2 label {
  display: block;
}
#checkboxes3 label {
  display: block;
}
#checkboxes4 label {
  display: block;
}
#checkboxes5 label {
  display: block;
}
#checkboxes0 label:hover {
  background-color: #1e90ff;
}

#checkboxes1 label:hover {
  background-color: #1e90ff;
}
.custom-select {
  position: relative;
  font-family: Arial;
}

.custom-select select {
  display: none; /*hide original SELECT element: */
}

.select-selected {
  background-color: DodgerBlue;
}

/* Style the arrow inside the select element: */
.select-selected:after {
  position: absolute;
  content: "";
  top: 14px;
  right: 10px;
  width: 0;
  height: 0;
  border: 6px solid transparent;
  border-color: #fff transparent transparent transparent;
}

/* Point the arrow upwards when the select box is open (active): */
.select-selected.select-arrow-active:after {
  border-color: transparent transparent #fff transparent;
  top: 7px;
}

/* style the items (options), including the selected item: */
.select-items div,.select-selected {
  color: #ffffff;
  padding: 8px 16px;
  border: 1px solid transparent;
  border-color: transparent transparent rgba(0, 0, 0, 0.1) transparent;
  cursor: pointer;
}

/* Style items (options): */
.select-items {
  position: absolute;
  background-color: DodgerBlue;
  top: 100%;
  left: 0;
  right: 0;
  z-index: 99;
}

/* Hide the items when the select box is closed: */
.select-hide {
  display: none;
}

.select-items div:hover, .same-as-selected {
  background-color: rgba(0, 0, 0, 0.1);
}
</style>  


<script>
//https://www.qodo.co.uk/blog/javascript-select-all-options-for-a-select-box/
//https://www.javascripttutorial.net/javascript-dom/javascript-select-box/
//https://stackoverflow.com/questions/2617629/how-to-get-all-elements-inside-div-that-starts-with-a-known-text
//https://stackoverflow.com/questions/23150041/get-checkbox-value-of-items-within-div
    function examstr(num){
    const int = num;
    const examcheck = document.getElementById("exam"+int).checked;
    const children = document.getElementById("checkboxes"+int).children;
    var checkedCbs = document.querySelectorAll('#checkboxes'+int+' input[type="checkbox"]');
    const exam_name = document.getElementById("bean"+int).children[0].value;
    const exam_name_end_index = exam_name.lastIndexOf(' ');
    const exam_name_only = exam_name.substring(0,exam_name_end_index);
    if (examcheck){
//        document.getElementById("examchoice").innerHTML += "e"+num+",";
//        document.getElementById("examchoice").innerHTML += "_"+exam_name_only;
        for (var i = 0; i < checkedCbs.length; i++){
            checkedCbs[i].click();
        }
    } else {
//        document.getElementById("examchoice").innerHTML = document.getElementById("examchoice").innerHTML.replace(("e"+num+","),"");
        for (var i = 0; i < checkedCbs.length; i++){
//            checkedCbs[i].checked=false;
            checkedCbs[i].click();
        }
    }
} 


//https://www.w3schools.com/jsref/event_preventdefault.asp

function verstr(exam,int){
    const vercheck = document.getElementById("vercheck"+exam+"-"+int).checked;
    const system_name = document.getElementById("vercheck"+exam+"-"+int).parentNode.getElementsByTagName('span')[0].innerHTML;
    const system_name_end_index = system_name.lastIndexOf(' ');
    const system_name_only = system_name.substring(0,system_name_end_index);
    //https://stackoverflow.com/questions/10143211/javascript-innerhtml-of-checkbox
    const exam_name = document.getElementById("bean"+exam).children[0].value;
    const exam_name_end_index = exam_name.lastIndexOf(' ');
    const exam_name_only = exam_name.substring(0,exam_name_end_index);
    var numtomaxindexfirst = system_name.indexOf('(');
    var numtomaxindexlast = system_name.lastIndexOf(')');
    var numtomax = system_name.substring(numtomaxindexfirst+1,numtomaxindexlast);
    var intnumtomax = parseInt(numtomax);
    var currnumbmax = document.getElementById("maxnoques").innerHTML;
    var intcurrmax = parseInt(currnumbmax);
    if (vercheck){
//        document.getElementById("versionchoice").innerHTML += "e"+exam+"s"+int+",";
        document.getElementById("versionchoice").innerHTML +="\'"+system_name_only+"\',";
        document.getElementById("examchoice").innerHTML +="\'"+exam_name_only+"\',";
        document.getElementById("maxnoques").innerHTML = intcurrmax+intnumtomax;
    } else {
        document.getElementById("versionchoice").innerHTML = document.getElementById("versionchoice").innerHTML.replace(("\'"+system_name_only+"\',"),"");
        document.getElementById("examchoice").innerHTML = document.getElementById("examchoice").innerHTML.replace(("\'"+exam_name_only+"\',"),"");
        document.getElementById("maxnoques").innerHTML = intcurrmax-intnumtomax;
    }
}
function sysstr(nom){
    const syscheck = document.getElementById("syscheck"+nom).checked;
    if (syscheck){
        document.getElementById("systemchoice").innerHTML += nom+",";
    } else {
        document.getElementById("systemchoice").innerHTML = document.getElementById("systemchoice").innerHTML.replace((nom+","),"");
    }
}
function subsysstr(nint){
    const subsysstr = document.getElementById("subsyscheck"+nint).checked;
    if (subsysstr){
        document.getElementById("subsystemchoice").innerHTML += nint+",";
    } else {
        document.getElementById("subsystemchoice").innerHTML = document.getElementById("subsystemchoice").innerHTML.replace((nint+","),"");
    }
}
function pagestr(){
//    document.getElementById('generated').setAttribute("onclick","window.location.href='main.php'");
    document.getElementById('generated').innerHTML = "timed";
}
function orgstr(){
//    document.getElementById('generated').setAttribute("onclick","window.location.href='sliderattempt4.php'");
    document.getElementById('generated').innerHTML = "tutor";
}

//========================================================================================
//========================================================================================
//========================================================================================
//Use this function to push question category string to data.php, explanationdata.php and optiondata.php
//use manager-osx to restart myadminphp
//========================================================================================
//========================================================================================
//========================================================================================
var dict = [];
//https://stackoverflow.com/questions/40711300/javascript-do-something-every-n-seconds
function genstr(){
    var examstr = document.getElementById("examchoice").innerHTML;
    var verstr = document.getElementById("versionchoice").innerHTML;
//    var sysstr = document.getElementById("systemchoice").innerHTML;
//    var subsysstr = document.getElementById("subsystemchoice").innerHTML;
    var noques = document.getElementById("noques").value;
    dict.push(("examstr"),examstr);
    dict.push(("verstr"),verstr);
//    dict.push(("sysstr"),sysstr);
//    dict.push(("subsysstr"),subsysstr);
    dict.push(("noques"),noques);
//    alert(dict);
}

function submitform(){
    //Salute to this guy: https://attacomsian.com/blog/xhr-json-response
    //And this guy: https://stackoverflow.com/questions/32824360/run-php-function-on-button-click
//        document.getElementById("subbuttonhere").innerHTML = "<input type=\'submit\' name=\'submit\' id=\'examsubmit\' value=\'Add Invoic\'>";      
//        document.getElementById("examsubmit").click();
    document.getElementById("nothingbutton").click();
    if (document.getElementById("loadtablevalue").innerHTML===''){
        const jsondict = JSON.stringify(dict);
        document.getElementById("dictarray").innerHTML = jsondict;
        const xhr = new XMLHttpRequest();
        xhr.open("POST","tablequery3.php",true);
        xhr.send(jsondict);
        xhr.onload = () => {
            var data = JSON.parse(xhr.responseText);
            console.log(data);
            localStorage.setItem('data',JSON.stringify(data));
        };
    } else if (document.getElementById("loadtablevalue").innerHTML==='answered'){
        const jsondict = JSON.stringify(dict);
        document.getElementById("dictarray").innerHTML = jsondict;
        const xhr = new XMLHttpRequest();
        xhr.open("POST","userttemptsquery.php",true);
        xhr.send(jsondict);
        xhr.onload = () => {
            var data = JSON.parse(xhr.responseText);
            console.log(data);
            localStorage.setItem('data',JSON.stringify(data));
        };
    } else if (document.getElementById("loadtablevalue").innerHTML==='unanswered'){
        const jsondict = JSON.stringify(dict);
        document.getElementById("dictarray").innerHTML = jsondict;
        const xhr = new XMLHttpRequest();
        xhr.open("POST","unansweredquery.php",true);
        xhr.send(jsondict);
        xhr.onload = () => {
            var data = JSON.parse(xhr.responseText);
            console.log(data);
            localStorage.setItem('data',JSON.stringify(data));
        };
    } else if (document.getElementById("loadtablevalue").innerHTML==='marked'){
        const jsondict = JSON.stringify(dict);
        document.getElementById("dictarray").innerHTML = jsondict;
        const xhr = new XMLHttpRequest();
        xhr.open("POST","markedquery.php",true);
        xhr.send(jsondict);
        xhr.onload = () => {
            var data = JSON.parse(xhr.responseText);
            console.log(data);
            localStorage.setItem('data',JSON.stringify(data));
        };
    }
    
    var only_one = document.getElementsByName("only_one");
    //          if (only_one[0].checked===true && localStorage.getItem('data')!==null){
    //              window.location.href='sliderattempt4.php';
    //          } else if (only_one[1].checked===true && localStorage.getItem('data')!==null){
    //              window.location.href='main.php';
    //          } else {
    //              console.log("none_one selected");
    //          }
}
function nextpage(){
    const maxqueno = document.getElementById("maxnoques").innerHTML;
    const intmaxqueno = parseInt(maxqueno);
    const nextpages = document.getElementById("generated").innerHTML;
    if (nextpages === "timed" && localStorage.getItem('data')!==null){
        window.location.href='timedslider.php';
    } else if (nextpages === "tutor" && localStorage.getItem('data')!==null){
        window.location.href='sliderattempt5.php';
    } else {
        window.setInterval(nextpage, 1000);
    }
}
    //function and field from https://www.youtube.com/watch?v=OX7OYDf2FJc
function minMaxValidationFunc(that, value){
    const maxqueno = document.getElementById("maxnoques").innerHTML;
    const intmaxqueno = parseInt(maxqueno);
    const max = Math.min(40, intmaxqueno);
    const min = parseInt(that.getAttribute("min"));
    const val = parseInt(value);
    if (val < min || isNaN(val) ){
        return min;
    } else if (val>max){
        return max;
    } else {
        return val;
    }
}
//function examcheck(){
//    var formreference = document.getElementsByName("containers");
////    var  bbbb = document.getElementById("sideLine").rows.length;
//    for (var x = 0; x<formreference.length; x++){
//        var veritem = document.getElementById("vercheck"+x).innerHTML;
//        var start = veritem.indexOf("(");
//        var numquestions = veritem.substring(start+1,veritem.length-1);
//        if (numquestions == 4){
//            document.getElementById("vercheckbutt"+x).disabled=true;
//        }
//    }
//}
var answered = "answered";
var all = "all";
var unanswered = "unanswered";
var marked = "marked";
function loadtable(strval){
    if (strval==='all'){
       document.getElementById("loadtablevalue").innerHTML = 'all'; 
    } else if (strval==='answered'){
        document.getElementById("loadtablevalue").innerHTML = 'answered';
    } else if (strval==='unanswered'){
        document.getElementById("loadtablevalue").innerHTML = 'unanswered';
    } else if (strval==='marked'){
        document.getElementById("loadtablevalue").innerHTML = 'marked';
    }
}
function showCheckboxes(num) {
  var checkboxes = document.getElementById("checkboxes"+num);
  var expanded = document.getElementById("expanded"+num).innerHTML;
  if (expanded==="false") {
    checkboxes.style.display = "block";
    document.getElementById("expanded"+num).innerHTML = "true";
  } else {
    checkboxes.style.display = "none";
    document.getElementById("expanded"+num).innerHTML = "false";
  }
}
//Naveen @ https://stackoverflow.com/questions/19206919/how-to-create-checkbox-inside-dropdown

</script>
</head>
<body>
    <table>
        <tr>
            <tr style="height:50px"></tr>
            <td style="width:150px"></td>
            <td>
                <canvas id="can" width="200" height="200" />
            </td>
        </tr>
        <tr>
            <td style="width:150px"></td>
            <td style="text-align: center">
            <p id="wordspercent"></p>
            </td>
        </tr>
    </table>
    <?php
//    print_r(PDO::getAvailableDrivers());
    $dbhost = "localhost";
    $dbuser = "root";
    $dbpass = "";
    $dbname = "demoquestions";
    include_once "dbh.inc.php";
    include_once "user.inc.php";
//    $connection = mysqli_connect($dbhost, $dbuser, $dbpass, $dbname);
//    $mysqli = NEW MySQLi($dbhost, $dbuser, $dbpass, $dbname);
//    $resultSet = $mysqli->query("SELECT `exam`, COUNT(*) AS `count` FROM questions GROUP BY `exam`");
    //https://stackoverflow.com/questions/16707780/count-how-many-rows-have-the-same-value
//    $resultSet2 = $mysqli->query("SELECT `system`, COUNT(*) FROM questions GROUP BY `exam`,`system`");
    //https://stackoverflow.com/questions/32470232/dropdown-from-database-without-duplicate-data
    //extract html tags and their attributes w-shadow
    
//    $color1 = "lightblue";
//    $color2 = "white";
//    $color = $color1;
    ?>
<!--    <select name="exams">-->
            <table class="row" id="examandsystems">
                <tr>
                    <td>
                        <?php
        //                var_dump($userid);
//                            echo $_SESSION["useridnum"];
                        function testfun()
                        {
                            $userid = $_SESSION["userid"];
                            $object = new user;
                            echo $object -> getAll();
                            
                        }
                        if(array_key_exists('test',$_POST)){
                           testfun();
                        }
                        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


                        function testfun1()
                        {
                            $userid = $_SESSION["userid"];
                            $object = new user;
                            echo $object -> getIncorrects();
                            $answered = 'answered';
                           
                        }
                        if(array_key_exists('test1',$_POST)){
                           testfun1();
                        }
                        function testfun2()
                        {
                            $userid = $_SESSION["userid"];
                            $object = new user;
                            echo $object -> getUnanswered();
                            $unanswered = 'unanswered';
                            $color1 = "lightblue";
                            $color2 = "white";
                            $color = $color1;
                        }
                        if(array_key_exists('test2',$_POST)){
                           testfun2();
                        }

                        function testfun3()
                        {
                            $userid = $_SESSION["userid"];
                            $marked = 'marked';
                            $object = new user;
                            echo $object -> getMarked();
                            
                        }
                        if(array_key_exists('test3',$_POST)){
                           testfun3();
                        }
                        ?>  
                    </td>
                </tr>
            </table>

            <table class="row">
                <tr>
                    <td style="width:150px"></td>
                    <td>
                        <label class="retainer">Tutor
                            <input type="radio" name="only_one" id="tutor" onClick="orgstr()">
                            <span class="radio"></span>
                        </label>
                        <label class="retainer">Timed
                            <input type="radio" name="only_one" id="timed" onClick="pagestr();">
                            <span class="radio"></span>
                        </label>
                        <label class="retainer">Adaptive
                            <input type="radio" name="only_one" id="timed" onClick="pagestr();">
                            <span class="radio"></span>
                        </label>
                    </td>
                </tr>
            </table>

    <!--    ============================================
                ============================================-->
    <div class="text-center">
        <table>
            <tr>
                <td style="width:150px"></td>
                <td>
                    <label>Number of Questions</label>
                    <input type="text" style="width:20px" onblur="this.value = minMaxValidationFunc(this, this.value)" min="2" max="40" id="noques"/>
                </td>
            </tr>
            <tr>
                <td style="width:150px"></td>
                <td>
                    <button type="button" id="generate" onclick="genstr();submitform();nextpage();">Generate</button>
                    <p id="generated" style="display:none;">tutor</p>
                    <p id="maxnoques" style="display:none;">0</p>                
                </td>
            </tr>
        </table>
    </div>
    <!--nextpage();-->
    
<!--    <button type="button" id="examcheck" onclick="examcheck();">Exam Check</button>-->
    <!--https://www.w3docs.com/snippets/html/how-to-create-an-html-button-that-acts-like-a-link.html-->
    <!--window.location.href='sliderattempt3.php';-->
    <p id="examchoice" style="display:none;"></p>
    <p id="versionchoice" style="display:none;"></p>
    <p id="systemchoice" style="display:none;"></p>
    <p id="subsystemchoice" style="display:none;"></p>
    <p id="dictarray" style="display:none;"></p>
    <table> 
        <tr>
            <td style="width:150px"></td>
            <td>
                <!--<form method="post" onsubmit="test.disabled = true; return true;">-->
                <form method="post" onsubmit="return true;">
                <input type="submit" name="test" id="test" value="All" onclick="loadtable('all');" style="color:white;padding:5px 15px;font-size:17px;background-color:blue;border:none;border-radius:5px;"/><br/>
                </form>
            </td>
            <td>
                <form method="post" onsubmit="myButton.disabled = true; return true;">
                <input type="submit" name="test1" id="test1" value="Incorrect" onclick="loadtable('answered');" style="color:white;padding:5px 15px;font-size:17px;background-color:blue;border:none;border-radius:5px;"/><br/>
                </form>
            </td>
            <td>
                <form method="post" onsubmit="myButton.disabled = true; return true;">
                <input type="submit" name="test2" id="test2" value="Unanswered" onclick="loadtable('unanswered');" style="color:white;padding:5px 15px;font-size:17px;background-color:blue;border:none;border-radius:5px;"/><br/>
                </form>
            </td>
            <td>
                <form method="post" onsubmit="myButton.disabled = true; return true;">
                <input type="submit" name="test3" id="test3" value="Marked" onclick="loadtable('marked');" style="color:white;padding:5px 15px;font-size:17px;background-color:blue;border:none;border-radius:5px;"/><br/>
                </form>
            </td>
        </tr>
    </table>
    <p id="loadtablevalue" style="display:none;"></p>
    <button id="nothingbutton" style="display:none;"></button>
<!--    prevent default form behavior https://www.youtube.com/watch?v=4_WfwSFGJuE-->
<!--    <form method='POST' action='server.php' onsubmit="myFunc();">
        <input type='submit' />
    </form>-->
    <script>
        function myFunc(){
            event.preventDefault();
        }
    </script>
<!--    <form method='POST' action='server.php' onsubmit="return myFunc2();">
        <input type='submit' />
    </form>-->
    <script>
        function myFunc2(){
            return false;
        }
    </script>

<!--  <div class="multiselect">
    <div class="selectBox" onclick="showCheckboxes(0)">
      <select>
        <option>Select an option</option>
      </select>
      <div class="overSelect"></div>
    </div>
    <div id="checkboxes0">
      <label for="one0">
        <input type="checkbox" id="one0" />First checkbox</label>
    </div>
  </div>-->
  <!--Naveen @ https://stackoverflow.com/questions/19206919/how-to-create-checkbox-inside-dropdown--> 
<!--  <div id="expanded0" style="display:none;">false</div>
  <div id="expanded1" style="display:none;">false</div>-->
</body>
</html>
<script>
// Pie Chart   https://stackoverflow.com/questions/6995797/html5-canvas-pie-chart
function delay(milliseconds){
        return new Promise(resolve => {
            setTimeout(resolve,milliseconds);
        });
    }
let piecounts = [];
function getcountsforpie(){
    
    var ajax = new XMLHttpRequest();
    ajax.open("GET", "percentcorr.php", true);
    ajax.send();
    ajax.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
        var counts = JSON.parse(this.responseText);
        piecounts[0]=parseInt(counts[0]);
        piecounts[1]=parseInt(counts[1]);
        piecounts[2]=parseInt(counts[2]);
//        console.log(piecounts);
        }
    }
}
async function makechart(){
    var canvas = document.getElementById("can");
    var ctx = canvas.getContext("2d");
    var lastend = 0;
    var myTotal = 0;
    var myColor = ['#f7042d', '#4DB524','#043df7'];
    var labels = ['Incorrect', 'Correct', 'Blank'];
    // make the chart 10 px smaller to fit on canvas
    var off = 10;
    var w = (canvas.width - off) / 2;
    var h = (canvas.height - off) / 2;

    for(var e = 0; e < piecounts.length; e++)
    {
      myTotal += piecounts[e];
      document.getElementById("wordspercent").innerHTML = Math.round(((piecounts[1])/(myTotal))*100)+" Percent Correct";
    }
    for (var i = 0; i < piecounts.length; i++) {
    ctx.fillStyle = myColor[i];
    ctx.strokeStyle ='white';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(w,h);
    var len =  (piecounts[i]/myTotal) * 2 * Math.PI
    var r = h - off / 2;
    ctx.arc(w , h, r, lastend,lastend + len,false);
    ctx.lineTo(w,h);
    ctx.fill();
    ctx.stroke();
    ctx.fillStyle ='white';
    ctx.font = "20px Arial";
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    var mid = lastend + len / 2;
    ctx.fillText(labels[i],w + Math.cos(mid) * (r/2) , h + Math.sin(mid) * (r/2));
    lastend += Math.PI*2*(piecounts[i]/myTotal);
    }
}
function secondmakechart(){
    if (piecounts.length>0){
        makechart();
    }
}
setInterval(secondmakechart,5);
window.addEventListener("load", myInit, true); function myInit(){
    localStorage.clear();
    getcountsforpie();
}

</script>