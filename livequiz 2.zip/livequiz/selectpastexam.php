<?php
    session_start();
    include "loginstuff/access.php";
    access();
    $userid = '';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Past Exams</title>
<header class="header-fixed">
	<div class="header-limiter">
		<h1><a href="#">ADAPTIVE<span>Test Bank</span></a></h1>
		<nav>
                    <a href="../quiz/loginstuff/windex.php" style="color:#EAAA00"><b>Home</b></a>
                    <a href="selectpastexam.php" style="color:#5383d3"><b>Past Exams</b></a>
                    <a href="selectdata4.php" style="color:#EAAA00" name="submit" onclick="window.location.href='http://localhost/quiz/selectdata4.php';"><b>Make Exam</b></a>
                    <a href="#" style="color:#5383d3"><b>|</b></a>
                        <?php
                            if(isset($_SESSION["userid"])){
                        ?>
                    <a href="#" style="color:#5383d3"><b><?php echo $_SESSION["useruid"]; ?></b></a>
                    <a href="../quiz/loginstuff/includes/logout.inc.php" class="header-login-a" style="text-decoration:none;color:#EAAA00;">Log Out</a>
                        <?php
                            }
                            else
                            {
                        ?>
                            <a href="#" style="color:#5383d3"><b>Sign Up</b></a>
                            <a href="#" class="header-login-a" style="color:#EAAA00"><b>Log In</b></a>
                        <?php
                        }
                        ?>
		</nav>
	</div>
</header>
<style>
.header-fixed {
	background-color:#292c2f;
	box-shadow:0 1px 1px #ccc;
	padding: 20px 40px;
	height: 80px;
	color: #A2AAAD;
	box-sizing: border-box;
	top:-100px;

	-webkit-transition:top 0.3s;
	transition:top 0.3s;
}

.header-fixed .header-limiter {
	max-width: 1200px;
	text-align: center;
	margin: 0 auto;
        color:#A2AAAD;
}

/*	The header placeholder. It is displayed when the header is fixed to the top of the
	browser window, in order to prevent the content of the page from jumping up. */

.header-fixed-placeholder{
	height: 80px;
	display: none;
}


.header-fixed .header-limiter h1 {
	float: left;
	font: normal 28px Cookie, Arial, Helvetica, sans-serif;
	line-height: 40px;
	margin: 0;
}

.header-fixed .header-limiter h1 span {
	color: #5383d3;
}

/* The navigation links */

.header-fixed .header-limiter a {
	color: #EAAA00;
	text-decoration: none;
}

.header-fixed .header-limiter nav {
	font:16px Arial, Helvetica, sans-serif;
	line-height: 40px;
	float: right;
}

.header-fixed .header-limiter nav a{
	display: inline-block;
	padding: 0 5px;
	text-decoration:none;
	color: #ffffff;
	opacity: 0.9;
}

.header-fixed .header-limiter nav a:hover{
	opacity: 1;
}

.header-fixed .header-limiter nav a.selected {
	color: #608bd2;
	pointer-events: none;
	opacity: 1;
}

/* Fixed version of the header */

body.fixed .header-fixed {
	padding: 10px 40px;
	height: 50px;
	position: fixed;
	width: 100%;
	top: 0;
	left: 0;
	z-index: 1;
}

body.fixed .header-fixed-placeholder {
	display: block;
}

body.fixed .header-fixed .header-limiter h1 {
	font-size: 24px;
	line-height: 30px;
}

body.fixed .header-fixed .header-limiter nav {
	line-height: 28px;
	font-size: 13px;
}


/* Making the header responsive */

@media all and (max-width: 600px) {

	.header-fixed {
		padding: 20px 0;
		height: 75px;
	}

	.header-fixed .header-limiter h1 {
		float: none;
		margin: -8px 0 10px;
		text-align: center;
		font-size: 24px;
		line-height: 1;
	}

	.header-fixed .header-limiter nav {
		line-height: 1;
		float:none;
	}

	.header-fixed .header-limiter nav a {
		font-size: 13px;
	}

	body.fixed .header-fixed {
		display: none;
	}

}

/*
	 We are clearing the body's margin and padding, so that the header fits properly.
	 We are also adding a height to demonstrate the scrolling behavior. You can remove
	 these styles.
 */

body {
	margin: 0;
	padding: 0;
	height: 1500px;
}    

        /* Customize the label (the container) */
.container {
  display: block;
  position: relative;
  padding-left: 35px;
  margin-bottom: 12px;
  cursor: pointer;
  font-size: 22px;
  -webkit-user-select: none;
  -moz-user-select: none;
  -ms-user-select: none;
  user-select: none;
}

/* Hide the browser's default checkbox */
.container input {
  position: absolute;
  opacity: 0;
  cursor: pointer;
  height: 0;
  width: 0;
}

/* Create a custom checkbox */
.checkmark {
  position: absolute;
  top: 0;
  left: 0;
  height: 25px;
  width: 25px;
  background-color: #eee;
}

/* On mouse-over, add a grey background color */
.container:hover input ~ .checkmark {
  background-color: #ccc;
}

/* When the checkbox is checked, add a blue background */
.container input:checked ~ .checkmark {
  background-color: #2196F3;
}

/* Create the checkmark/indicator (hidden when not checked) */
.checkmark:after {
  content: "";
  position: absolute;
  display: none;
}
.container:after{
  content: "";
  position: absolute;
  display: none;
  border-radius: 50%;
}
/* Show the checkmark when checked */
.container input:checked ~ .checkmark:after {
  display: block;
}

/* Style the checkmark/indicator */
.container .checkmark:after {
  left: 9px;
  top: 5px;
  width: 5px;
  height: 10px;
  border: solid white;
  border-width: 0 3px 3px 0;
  -webkit-transform: rotate(45deg);
  -ms-transform: rotate(45deg);
  transform: rotate(45deg);
}
/* Customize the label (the container) */
/*=================================================
=================================================*/
/* Customize the label (the container) */
.retainer {
  display: block;
  position: relative;
  padding-left: 35px;
  margin-bottom: 12px;
  cursor: pointer;
  font-size: 22px;
  -webkit-user-select: none;
  -moz-user-select: none;
  -ms-user-select: none;
  user-select: none;
}

/* Hide the browser's default radio button */
.retainer input {
  position: absolute;
  opacity: 0;
  cursor: pointer;
  height: 0;
  width: 0;
}

/* Create a custom radio button */
.radio {
  position: absolute;
  top: 0;
  left: 0;
  height: 25px;
  width: 25px;
  background-color: #eee;
  border-radius: 50%;
}

/* On mouse-over, add a grey background color */
.retainer:hover input ~ .radio {
  background-color: #ccc;
}

/* When the radio button is checked, add a blue background */
.retainer input:checked ~ .radio {
  background-color: #2196F3;
}

/* Create the indicator (the dot/circle - hidden when not checked) */
.radio:after {
  content: "";
  position: absolute;
  display: none;
}

/* Show the indicator (dot/circle) when checked */
.retainer input:checked ~ .checkmark:after {
  display: block;
}

/* Style the indicator (dot/circle) */
.retainer .radio:after {
  top: 9px;
  left: 9px;
  width: 8px;
  height: 8px;
  border-radius: 50%;
  background: white;
}
/*=================================================
=================================================*/
/* Customize the label (the container) */
/*=================================================
=================================================*/
/* Customize the label (the container) */
.retainerx {
  display: block;
  position: relative;
  padding-left: 35px;
  margin-bottom: 12px;
  /*cursor: pointer;*/
  font-size: 22px;
  color: grey;
  -webkit-user-select: none;
  -moz-user-select: none;
  -ms-user-select: none;
  user-select: none;
}

/* Hide the browser's default radio button */
/*https://jsfiddle.net/petrabarus/pPgS7/*/
.retainerx input {
  position: absolute;
  visibility:hidden;
  opacity: 0;
  cursor: pointer;
  height: 0;
  width: 0;
}

 /*Create a custom radio button*/ 
.radio {
  position: absolute;
  top: 0;
  left: 0;
  height: 25px;
  width: 25px;
  background-color: #eee;
  border-radius: 50%;
}

 /*On mouse-over, add a grey background color*/ 
.retainerx:hover input ~ .radio {
  background-color: #ccc;
  visibility:hidden;
}

 /*When the radio button is checked, add a blue background*/ 
.retainerx input:checked ~ .radio {
  background-color: #2196F3;
}

 /*Create the indicator (the dot/circle - hidden when not checked)*/ 
.radio:after {
  content: "";
  position: absolute;
  display: none;
}

 /*Show the indicator (dot/circle) when checked*/ 
.retainerx input:checked ~ .checkmark:after {
  display: block;
  visibility:hidden;
}

 /*Style the indicator (dot/circle)*/ 
.retainerx .radio:after {
  top: 9px;
  left: 9px;
  width: 8px;
  height: 8px;
  border-radius: 50%;
  background: white;
}
/*=================================================
=================================================*/
#heading{
    font-size: 22px;
}
#typeheading{
    font-size: 22px;
    float: right;
}
#generate{
    font-size: 22px;
}
.multiselect {
  width: 200px;
}

.selectBox {
  position: relative;
}

.selectBox select {
  width: 100%;
  font-weight: bold;
}

.overSelect {
  position: absolute;
  left: 0;
  right: 0;
  top: 0;
  bottom: 0;
}

#checkboxes0, #checkboxes1, #checkboxes2, #checkboxes3, #checkboxes4, #checkboxes5{
  display: none;
  border: 1px #dadada solid;
  font-size:20px;
}

#checkboxes0 label {
  display: block;
}

#checkboxes1 label {
  display: block;
}
#checkboxes2 label {
  display: block;
}
#checkboxes3 label {
  display: block;
}
#checkboxes4 label {
  display: block;
}
#checkboxes5 label {
  display: block;
}
#checkboxes0 label:hover {
  background-color: #1e90ff;
}

#checkboxes1 label:hover {
  background-color: #1e90ff;
}
</style>  


<script>
function genexam(num){
    const jsondict = JSON.stringify(num);
    const xhr = new XMLHttpRequest();
    xhr.open("POST","pastexamquery.php",true);
    xhr.send(jsondict);
    xhr.onload = () => {
        var data = JSON.parse(xhr.responseText);
        console.log(data);
        localStorage.setItem('data',JSON.stringify(data));
    }
    window.setInterval(nextpage, 1000);
}
function nextpage(){
//    window.setInterval(nextpage, 1000);
    window.location.href='pastexampicslider.php';
}
</script>

</head>
<body>
    <table class="row" id="examandsystems">
        <tr style="height:50px"></tr>
        <tr>
            <td>
                <?php
                $userid = $_SESSION["userid"];
                $all = 'all';
                $color1 = "#002855";
                $color2 = "#EAAA00";
                $color = $color1;
                $dbhost = "localhost";
                $dbuser = "root";
                $dbpass = "";
                $dbname = "demoquestions";
                $counter = 0;
                $mysqli = NEW MySQLi($dbhost, $dbuser, $dbpass, $dbname);
                $totnoquery = $mysqli->query("SELECT COUNT(DISTINCT exam_number) as 'count' FROM alluserattempts WHERE user_id = '$userid';");
                $rhyme = $totnoquery->fetch_assoc();
                $totnoquestions = $rhyme['count'];
                $resultSet = $mysqli->query("SELECT `exam_number`,`examdate` FROM `alluserattempts` "
                        . "WHERE `user_id` = '$userid' "
                        . "GROUP BY `exam_number` DESC;");
                while ($rows = $resultSet->fetch_assoc()) {
                    $color == $color1 ? $color = $color2 : $color = $color1;
                    $queryexam = $rows['exam_number'];
                    
//                    print_r($queryexam);
                    $exam = $totnoquestions-$counter;
                    $corr = "";
                    $incorr = "";
                    $blank = "";
                    $corrquery = $mysqli->query("SELECT correct_answer, COUNT(correct_answer) as count FROM `alluserattempts` "
                            . "WHERE user_id = '$userid' "
                            . "AND exam_number = '$queryexam' "
                            . "AND correct_answer = 1 "
                            . "GROUP BY correct_answer;");
                    while ($rows8 = $corrquery->fetch_assoc()){
                        $numcorr = $rows8['count'];
                        if ($numcorr!==null){
                            $corr = $numcorr;
                        } else {
                            $corr = 0;
                        }
                    }
                    $incorrquery = $mysqli->query("SELECT correct_answer, COUNT(correct_answer) as count FROM `alluserattempts` "
                            . "WHERE user_id = '$userid' "
                            . "AND exam_number = '$queryexam' "
                            . "AND correct_answer = 0 "
                            . "GROUP BY correct_answer;");
                    while ($rows9 = $incorrquery->fetch_assoc()){
                        $numincorr = $rows9['count'];
                        if ($numincorr!==null){
                            $incorr = $numincorr;
                        } else {
                            $incorr = 0;
                        }
                    }
                    $blankquery = $mysqli->query("SELECT correct_answer, COUNT(correct_answer) as count FROM `alluserattempts` "
                            . "WHERE user_id = '$userid' "
                            . "AND exam_number = '$queryexam' "
                            . "AND correct_answer = 9 "
                            . "GROUP BY correct_answer;");
                    while ($rows10 = $blankquery->fetch_assoc()){
                        $numblank = $rows10['count'];
                        if ($numblank!==null){
                            $blank = $numblank;
                        } else {
                            $blank = 0;
                        }
                    }
                    $totnoques = intval($corr)+intval($incorr)+intval($blank);
//                    print_r($somearray);
                    $examdatetime = $rows['examdate'];
                    //https://stackoverflow.com/questions/22991021/php-to-round-up-to-the-2nd-decimal-place
                    $percentcorr = floor(((intval($corr)/(intval($corr)+intval($incorr)+intval($blank))))*100);
//                  Day Month Year Date  https://stackoverflow.com/questions/44105427/how-to-display-date-as-day-month-year
                    $newDate = date("d M Y", strtotime($examdatetime));
                    $new_date = date('dS F Y', strtotime($newDate));
                    $echostring1 = "<tr><td style='width:150px'></td><td style='vertical-align:top;'>"
                            . "<button type='button' id='test$exam' style='color:white;padding:5px 15px;font-size:17px;background-color:$color;border:none;border-radius:5px;width:400px;' onclick='genexam($queryexam);'>"
                            . "Exam ".$exam." | ".$new_date." | ".$percentcorr." %  of ".$totnoques." Qs</button></td>";
                    $echostring2 = '';
                    $finalechostring = $echostring1.$echostring2."</div>"."<div id='expanded$counter' style='display:none;'>false</div></td></tr>";
                    echo $finalechostring;
                    $counter += 1;  
                }
                
                ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                
                ?>  
            </td>
        </tr>
    </table> 
</body>
</html>
