<?php
//Grab data
if (isset($_POST["submit"])){
    $uid = $_POST['uid'];
    $pwd = $_POST['pwd'];
    
}

//Instantiate SignupContr class
include "../classes/dbh.classes.php";
include "../classes/login.classes.php";
include "../classes/login-contr.classes.php";
$login = new loginContr($uid, $pwd);
//Running error handlers and user signup
$login->loginUser();
//Going back to the front page
header("location: ../windex.php?error=none");

