<?php
function access(){
    if(!isset($_SESSION["userid"])){
        header("Location: ../quiz/loginstuff/windex.php");
        die;
    }
}
