<?php
    session_start();
    include "access.php";
    access();
?>
<?php
  header( 'charset=UTF-8' );
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta http-equiv="Content-type" content="application/x-www-form-urlencoded; charset=UTF-8"/>
    <title id="smth">Document</title>
</head>
<body>
    <header>
        <ul class="menu-member">
            <?php
                if(isset($_SESSION["userid"])){
            ?>
                <li><a href="#"><?php echo $_SESSION["useruid"]; ?></a></li>
                <li><a href="includes/logout.inc.php" class="header-login-a">LOGOUT</a></li>
            <?php
                }
                else
                {
            ?>
                <li><a href="#">SIGN UP</a></li>
                <li><a href="#" class="header-login-a">LOGIN</a></li>
            <?php
            }
            ?>
        </ul>
    </header>
    <section class="index-login">
        <div class="wrapper">
            <div class="index-login-signup">
                <h4>SIGN UP</h4> 
                <p>Don't have an account yet? Sign up here!</p>
                <form action="includes/signup.inc.php" method="post">
                    <input type="text"name="uid" placeholder="Username" required>
                    <input type="password" name="pwd" placeholder="Password" required>
                    <input type="password" name="pwdRepeat" placeholder="Repeat Password" required>
                    <input type="text" name="email" placeholder="E-mail">
                    <br>
                    <button type="submit" name="submit">SIGN UP</button>
                </form>
            </div>
            <div class="index-login-login">
                <h4>LOGIN</h4>
                <p>Don't have an account yet? Sign up here!</p>
                <form action="includes/login.inc.php" method="post">
                    <input type="text" name="uid" placeholder="Username">
                    <input type="password" name="pwd" placeholder="Password">
                    <br>
                    <button type="submit" name="submit">LOGIN</button>
                </form>
            </div>
        </div>
    </section>
</body>    
</html>
<script>
//    https://matthewrayfield.com/articles/animating-urls-with-javascript-and-emojis/#╭──────────────◯╮01:50%E2%95%B101:50
    var f = ['🕐','🕑','🕒','🕓','🕔','🕕','🕖','🕗','🕘','🕙','🕚','🕛'];

    function loop() {
        document.title = "Adacptive Test Bank " + f[Math.floor((Date.now()/100)%f.length)];

        setTimeout(loop, 50);
    }

    loop();
</script>    