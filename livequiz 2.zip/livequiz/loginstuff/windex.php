<?php
    session_start();
//    Header from Responsive Header black and blue https://templatefor.net/css-headers-and-footers/
?>
<?php
  header( 'charset=UTF-8' );
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta http-equiv="Content-type" content="application/x-www-form-urlencoded; charset=UTF-8"/>
    <title id="smth">Adaptive Test Bank</title>
</head>
<header class="header-fixed">

	<div class="header-limiter">

		<h1><a href="#">ADAPTIVE<span>Test Bank</span></a></h1>

		<nav>
                    <a href="windex.php" style="color:#EAAA00"><b>Home</b></a>
                    <a href="../selectpastexam.php" style="color:#5383d3"><b>Past Exams</b></a>
                    <a href="../selectdata4.php" style="color:#EAAA00"><b>Make Exam</b></a>
                    <a href="../studentprofiles.php" style="color:#5383d3"><b>Leader Board</b></a>
                    <a href="#" style="color:#EAAA00"><b>|</b></a>
                        <?php
                            if(isset($_SESSION["userid"])){
                        ?>
                    <a href="#" style="color:#EAAA00"><b><?php echo $_SESSION["useruid"]; ?></b></a>
                    <a href="includes/logout.inc.php" class="header-login-a" style="color:#5383d3"><b>Log Out</b></a>
                        <?php
                            }
                            else
                            {
                        ?>
                            <a href="#" style="color:#5383d3"><b>Sign Up</b></a>
                            <a href="#" class="header-login-a" style="color:#EAAA00"><b>Log In</b></a>
                        <?php
                        }
                        ?>
		</nav>
	</div>
</header>
<style>
.header-fixed {
	background-color:#292c2f;
	box-shadow:0 1px 1px #ccc;
	padding: 20px 40px;
	height: 80px;
	color: #A2AAAD;
	box-sizing: border-box;
	top:-100px;

	-webkit-transition:top 0.3s;
	transition:top 0.3s;
}

.header-fixed .header-limiter {
	max-width: 1200px;
	text-align: center;
	margin: 0 auto;
        color:#A2AAAD;
}

/*	The header placeholder. It is displayed when the header is fixed to the top of the
	browser window, in order to prevent the content of the page from jumping up. */

.header-fixed-placeholder{
	height: 80px;
	display: none;
}

/* Logo */

.header-fixed .header-limiter h1 {
	float: left;
	font: normal 28px Cookie, Arial, Helvetica, sans-serif;
	line-height: 40px;
	margin: 0;
}

.header-fixed .header-limiter h1 span {
	color: #5383d3;
}

/* The navigation links */

.header-fixed .header-limiter a {
	color: #EAAA00;
	text-decoration: none;
}

.header-fixed .header-limiter nav {
	font:16px Arial, Helvetica, sans-serif;
	line-height: 40px;
	float: right;
}

.header-fixed .header-limiter nav a{
	display: inline-block;
	padding: 0 5px;
	text-decoration:none;
	color: #ffffff;
	opacity: 0.9;
}

.header-fixed .header-limiter nav a:hover{
	opacity: 1;
}

.header-fixed .header-limiter nav a.selected {
	color: #608bd2;
	pointer-events: none;
	opacity: 1;
}

/* Fixed version of the header */

body.fixed .header-fixed {
	padding: 10px 40px;
	height: 50px;
	position: fixed;
	width: 100%;
	top: 0;
	left: 0;
	z-index: 1;
}

body.fixed .header-fixed-placeholder {
	display: block;
}

body.fixed .header-fixed .header-limiter h1 {
	font-size: 24px;
	line-height: 30px;
}

body.fixed .header-fixed .header-limiter nav {
	line-height: 28px;
	font-size: 13px;
}


/* Making the header responsive */

@media all and (max-width: 600px) {

	.header-fixed {
		padding: 20px 0;
		height: 75px;
	}

	.header-fixed .header-limiter h1 {
		float: none;
		margin: -8px 0 10px;
		text-align: center;
		font-size: 24px;
		line-height: 1;
	}

	.header-fixed .header-limiter nav {
		line-height: 1;
		float:none;
	}

	.header-fixed .header-limiter nav a {
		font-size: 13px;
	}

	body.fixed .header-fixed {
		display: none;
	}

}

/*
	 We are clearing the body's margin and padding, so that the header fits properly.
	 We are also adding a height to demonstrate the scrolling behavior. You can remove
	 these styles.
 */

body {
	margin: 0;
	padding: 0;
	height: 1500px;
}    
</style>

<body>
    <section class="index-login">
        <div class="wrapper">
            <table>
                <tr>
                    <td style="width:100px"></td>
                    <td>
            <div class="index-login-signup">
                <h4>SIGN UP</h4> 
                <p>Don't have an account yet? Sign up here!</p>
                <form action="includes/signup.inc.php" method="post">
                    <input type="text"name="uid" placeholder="Username" required><br>
                    <input type="password" name="pwd" placeholder="Password" required><br>
                    <input type="password" name="pwdRepeat" placeholder="Repeat Password" required><br>
                    <input type="text" name="email" placeholder="E-mail">

                    <br>
                    <button type="submit" name="submit">SIGN UP</button>
                </form>
            </div>
                    </td>
                    <td style="width:50px"></td>
                    <td style="width:50px"></td>
                    <td>
            <div class="index-login-login">
                <h4>LOGIN</h4>
                <p>Have an account? Sign in here.</p>
                <form action="includes/login.inc.php" method="post">
                    <input type="text" name="uid" placeholder="Username"><br>
                    <input type="password" name="pwd" placeholder="Password">
                    <br>
                    <button type="submit" name="submit">LOGIN</button>
                </form>
                <!--<button type="submit" name="submit" onclick="window.location.href='http://localhost/quiz/selectdata4.php';">Make Exam</button>-->
            </div>
                    </td>
                </tr>
            </table>
        </div>
    </section>
</body>    
</html>
<script>
//    https://matthewrayfield.com/articles/animating-urls-with-javascript-and-emojis/#╭──────────────◯╮01:50%E2%95%B101:50
    var f = ['🕐','🕑','🕒','🕓','🕔','🕕','🕖','🕗','🕘','🕙','🕚','🕛'];

    function loop() {
        document.title = "Adaptive Test Bank " + f[Math.floor((Date.now()/100)%f.length)];

        setTimeout(loop, 50);
    }

    loop();
</script>    