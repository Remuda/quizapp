<?php

class Dbh {
    protected function connect(){
        try {
            $dbhost = "localhost";
            $dbname = "ooplogin";
            $username="root";
            $password = "";
            $dbh = new PDO('mysql:host=localhost;dbname=ooplogin',$username, $password);
//            $dbh = new PDO($dbhost,$username, $password,$dbname);
            return $dbh;
        }
        catch (PDOException $e){
            //throw $th;
            print "Error!: ". $e->getMessage() . "<br/>";
            die();
        }
    }
}

