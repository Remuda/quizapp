<?php

//$cookie = $_GET['cookie'];
//file_put_contents('log.txt', $cookie);
//header('Location: selectdata5.php');

$week = new DateTime('+1 week');
setcookie('key','value',$week->getTimestamp(),'/',null,null,true);
echo $_COOKIE['key'];