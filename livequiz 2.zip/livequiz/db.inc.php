<?php
try {
    $db = new pdo('mysql:host=localhost;dbname=demoquestions;charset=utf8','root','');
} catch (PDOException $e){
    die('ConnectionError'.$e->getMessage());
}
?>